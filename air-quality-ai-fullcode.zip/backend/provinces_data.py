# -*- coding: utf-8 -*-
"""
Master 34 Provinces and 105 Monitoring Stations for Backend Service
Synchronized Real-Time Meteorological & Air Quality Data (2026-11-08 12:45:43)
"""

PROVINCES_34 = [
  {
    "id": "VN_HN",
    "name": "Hà Nội",
    "province": "Hà Nội",
    "region": "Miền Bắc",
    "type": "Thành phố",
    "lat": 21.0285,
    "lon": 105.8542,
    "condition": "light_rain",
    "weather_text": "Mưa rào rải rác, ngắt quãng",
    "temp": 26.2,
    "feels_like": 31.0,
    "humidity": 80,
    "wind_speed": 1.9,
    "wind_dir": "Tây",
    "rain_prob": 14,
    "rain_mm": 0.1,
    "uv": 6.1,
    "pressure": 1016,
    "visibility": 13.3,
    "pm25": 11.0,
    "pm10": 11.6,
    "no2": 6.0,
    "co": 0.87,
    "o3": 113.0,
    "so2": 19.0,
    "outdoor_activities": [
      "Đi dạo",
      "Chụp ảnh",
      "Du lịch"
    ],
    "outdoor_score": 82,
    "best_time": "08:30 - 11:00, 14:30 - 17:30",
    "outdoor_advice": "Thời tiết dễ chịu, thích hợp tham quan phố cổ, hồ Gươm; sáng sớm nên đeo khẩu trang do bụi tích tụ.",
    "station_id": "VN_HN",
    "station_name": "Trạm Hà Nội",
    "district": "Hà Nội",
    "latitude": 21.0285,
    "longitude": 105.8542,
    "temperature": 26.2,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_HN_01",
        "name": "Trạm Ba Đình - Trung tâm Hành chính",
        "type": "Đô thị / Hành chính",
        "address": "Số 1 Hoàng Hoa Thám, P. Ba Đình",
        "lat": 21.0342,
        "lon": 105.836,
        "pm25": 11.0,
        "pm10": 16.5,
        "aqi": 20,
        "temp": 26.2,
        "humidity": 82,
        "wind": 1.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_02",
        "name": "Trạm Hoàn Kiếm - Phố Cổ",
        "type": "Dân cư / Thương mại",
        "address": "Số 2 Hàng Trống, P. Hàng Trống",
        "lat": 21.0289,
        "lon": 105.8524,
        "pm25": 12.2,
        "pm10": 18.3,
        "aqi": 22,
        "temp": 26.6,
        "humidity": 82,
        "wind": 2.3,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_03",
        "name": "Trạm Cầu Giấy - Giao thông",
        "type": "Giao thông huyết mạch",
        "address": "Đường Cầu Giấy, P. Dịch Vọng",
        "lat": 21.0365,
        "lon": 105.7952,
        "pm25": 11.0,
        "pm10": 16.5,
        "aqi": 20,
        "temp": 26.2,
        "humidity": 83,
        "wind": 1.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_04",
        "name": "Trạm Đống Đa - Nguyễn Lương Bằng",
        "type": "Khu dân cư mật độ cao",
        "address": "Đường Nguyễn Lương Bằng, Q. Đống Đa",
        "lat": 21.0189,
        "lon": 105.8267,
        "pm25": 11.0,
        "pm10": 16.5,
        "aqi": 20,
        "temp": 26.2,
        "humidity": 79,
        "wind": 1.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_05",
        "name": "Trạm Hai Bà Trưng - Minh Khai",
        "type": "Giao thông và dân cư",
        "address": "Đường Minh Khai, Q. Hai Bà Trưng",
        "lat": 21.0025,
        "lon": 105.8569,
        "pm25": 11.0,
        "pm10": 16.5,
        "aqi": 20,
        "temp": 26.2,
        "humidity": 78,
        "wind": 1.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_06",
        "name": "Trạm Tây Hồ - Lạc Long Quân",
        "type": "Đô thị sinh thái hồ",
        "address": "Đường Lạc Long Quân, Q. Tây Hồ",
        "lat": 21.0652,
        "lon": 105.8123,
        "pm25": 9.8,
        "pm10": 14.7,
        "aqi": 18,
        "temp": 25.8,
        "humidity": 77,
        "wind": 1.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_07",
        "name": "Trạm Long Biên - Nguyễn Văn Cừ",
        "type": "Khu cửa ngõ phía Đông",
        "address": "Đường Nguyễn Văn Cừ, Q. Long Biên",
        "lat": 21.0489,
        "lon": 105.8785,
        "pm25": 11.0,
        "pm10": 16.5,
        "aqi": 20,
        "temp": 26.2,
        "humidity": 78,
        "wind": 1.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HN_08",
        "name": "Trạm Hà Đông - Quang Trung",
        "type": "Khu đô thị vệ tinh",
        "address": "Đường Quang Trung, Q. Hà Đông",
        "lat": 20.9712,
        "lon": 105.7725,
        "pm25": 10.4,
        "pm10": 15.6,
        "aqi": 19,
        "temp": 26.0,
        "humidity": 79,
        "wind": 1.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HN",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 23.3,
        "humidity": 96,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 23.1,
        "humidity": 97,
        "rain_prob": 88,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 22.2,
        "humidity": 100,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.1,
        "humidity": 97,
        "rain_prob": 98,
        "condition": "thunderstorm"
      },
      {
        "time": "04:00",
        "temp": 22.5,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.5,
        "humidity": 98,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.6,
        "humidity": 97,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.9,
        "humidity": 94,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 23.5,
        "humidity": 92,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 24.5,
        "humidity": 87,
        "rain_prob": 80,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 26.3,
        "humidity": 80,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 27.2,
        "humidity": 77,
        "rain_prob": 83,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 27.1,
        "humidity": 78,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 25.9,
        "humidity": 81,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 25.5,
        "humidity": 87,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 23.3,
        "humidity": 94,
        "rain_prob": 100,
        "condition": "thunderstorm"
      },
      {
        "time": "16:00",
        "temp": 24.0,
        "humidity": 91,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 24.1,
        "humidity": 92,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 22.8,
        "humidity": 96,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 23.1,
        "humidity": 94,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 23.0,
        "humidity": 95,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 23.1,
        "humidity": 94,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.5,
        "humidity": 94,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.6,
        "humidity": 94,
        "rain_prob": 97,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_HP",
    "name": "Hải Phòng",
    "province": "Hải Phòng",
    "region": "Miền Bắc",
    "type": "Thành phố",
    "lat": 20.8449,
    "lon": 106.6881,
    "condition": "light_rain",
    "weather_text": "Mưa phùn vừa phải, không khí ẩm",
    "temp": 28.7,
    "feels_like": 31.8,
    "humidity": 70,
    "wind_speed": 16.4,
    "wind_dir": "Đông",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 6.2,
    "pressure": 1017,
    "visibility": 13.6,
    "pm25": 6.1,
    "pm10": 6.8,
    "no2": 3.4,
    "co": 0.45,
    "o3": 120.0,
    "so2": 13.4,
    "outdoor_activities": [
      "Du lịch",
      "Đi dạo",
      "Chụp ảnh"
    ],
    "outdoor_score": 85,
    "best_time": "08:00 - 11:30, 15:00 - 18:00",
    "outdoor_advice": "Gió mát ven biển, thích hợp khám phá ẩm thực và dạo phố đi bộ Tam Bạc.",
    "station_id": "VN_HP",
    "station_name": "Trạm Hải Phòng",
    "district": "Hải Phòng",
    "latitude": 20.8449,
    "longitude": 106.6881,
    "temperature": 28.7,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_HP_01",
        "name": "Trạm Tam Bạc - Q. Hồng Bàng",
        "type": "Đô thị / Trung tâm",
        "address": "Đường Tam Bạc, P. Phan Bội Châu",
        "lat": 20.8601,
        "lon": 106.6782,
        "pm25": 6.1,
        "pm10": 9.1,
        "aqi": 11,
        "temp": 28.7,
        "humidity": 72,
        "wind": 16.4,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HP",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HP_02",
        "name": "Trạm KCN Đình Vũ - Cảng biển",
        "type": "Công nghiệp / Cảng",
        "address": "Bán đảo Đình Vũ, Q. Hải An",
        "lat": 20.8415,
        "lon": 106.7582,
        "pm25": 5.5,
        "pm10": 8.2,
        "aqi": 10,
        "temp": 28.5,
        "humidity": 70,
        "wind": 16.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HP",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HP_03",
        "name": "Trạm Đồ Sơn - Sinh thái Ven biển",
        "type": "Sinh thái biển",
        "address": "Khu 2 Đồ Sơn, Q. Đồ Sơn",
        "lat": 20.7125,
        "lon": 106.7891,
        "pm25": 4.9,
        "pm10": 7.4,
        "aqi": 9,
        "temp": 28.3,
        "humidity": 68,
        "wind": 16.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HP",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.4,
        "humidity": 88,
        "rain_prob": 74,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 25.2,
        "humidity": 90,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 24.8,
        "humidity": 90,
        "rain_prob": 97,
        "condition": "partly_cloudy"
      },
      {
        "time": "03:00",
        "temp": 24.7,
        "humidity": 90,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 24.2,
        "humidity": 92,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 23.4,
        "humidity": 96,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 23.4,
        "humidity": 97,
        "rain_prob": 87,
        "condition": "partly_cloudy"
      },
      {
        "time": "07:00",
        "temp": 24.7,
        "humidity": 87,
        "rain_prob": 78,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 25.9,
        "humidity": 79,
        "rain_prob": 66,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 27.4,
        "humidity": 73,
        "rain_prob": 54,
        "condition": "partly_cloudy"
      },
      {
        "time": "10:00",
        "temp": 28.4,
        "humidity": 70,
        "rain_prob": 47,
        "condition": "partly_cloudy"
      },
      {
        "time": "11:00",
        "temp": 28.9,
        "humidity": 69,
        "rain_prob": 53,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 28.5,
        "humidity": 68,
        "rain_prob": 66,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 28.8,
        "humidity": 70,
        "rain_prob": 73,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 28.8,
        "humidity": 69,
        "rain_prob": 69,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 28.6,
        "humidity": 68,
        "rain_prob": 59,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 28.1,
        "humidity": 71,
        "rain_prob": 51,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 27.5,
        "humidity": 72,
        "rain_prob": 45,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.6,
        "humidity": 79,
        "rain_prob": 40,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 26.4,
        "humidity": 79,
        "rain_prob": 41,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 26.1,
        "humidity": 80,
        "rain_prob": 54,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 24.7,
        "humidity": 85,
        "rain_prob": 75,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 24.0,
        "humidity": 92,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 23.6,
        "humidity": 94,
        "rain_prob": 96,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_HUE",
    "name": "Huế",
    "province": "Thừa Thiên Huế",
    "region": "Miền Trung",
    "type": "Thành phố",
    "lat": 16.4637,
    "lon": 107.5909,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 29.1,
    "feels_like": 34.3,
    "humidity": 73,
    "wind_speed": 12.2,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.8,
    "pressure": 1015,
    "visibility": 14.7,
    "pm25": 4.9,
    "pm10": 7.0,
    "no2": 0.8,
    "co": 0.34,
    "o3": 89.0,
    "so2": 2.2,
    "outdoor_activities": [
      "Tham quan",
      "Chụp ảnh"
    ],
    "outdoor_score": 68,
    "best_time": "09:00 - 11:30",
    "outdoor_advice": "Có mưa bay lãng mạn xứ Huế, thích hợp tham quan Đại Nội, chùa Thiên Mụ kèm ô/áo mưa mỏng.",
    "station_id": "VN_HUE",
    "station_name": "Trạm Huế",
    "district": "Huế",
    "latitude": 16.4637,
    "longitude": 107.5909,
    "temperature": 29.1,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_HUE_01",
        "name": "Trạm Đại Nội - Trung tâm Cố Đô",
        "type": "Đô thị di sản",
        "address": "Đường Đoàn Thị Điểm, P. Thuận Thành",
        "lat": 16.469,
        "lon": 107.578,
        "pm25": 4.3,
        "pm10": 6.4,
        "aqi": 8,
        "temp": 28.9,
        "humidity": 73,
        "wind": 12.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HUE",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HUE_02",
        "name": "Trạm Phố đi bộ Nguyễn Đình Chiểu",
        "type": "Du lịch ven sông Hương",
        "address": "Bờ sông Hương, P. Vĩnh Ninh",
        "lat": 16.462,
        "lon": 107.589,
        "pm25": 5.5,
        "pm10": 8.2,
        "aqi": 10,
        "temp": 29.3,
        "humidity": 72,
        "wind": 12.4,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HUE",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HUE_03",
        "name": "Trạm KCN Phú Bài & Sân bay",
        "type": "Giao thông công nghiệp",
        "address": "TX. Hương Thủy",
        "lat": 16.398,
        "lon": 107.698,
        "pm25": 4.9,
        "pm10": 7.4,
        "aqi": 9,
        "temp": 29.1,
        "humidity": 73,
        "wind": 12.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HUE",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.5,
        "humidity": 96,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 25.2,
        "humidity": 94,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "02:00",
        "temp": 25.0,
        "humidity": 93,
        "rain_prob": 20,
        "condition": "sunny"
      },
      {
        "time": "03:00",
        "temp": 24.9,
        "humidity": 94,
        "rain_prob": 41,
        "condition": "sunny"
      },
      {
        "time": "04:00",
        "temp": 24.4,
        "humidity": 96,
        "rain_prob": 53,
        "condition": "partly_cloudy"
      },
      {
        "time": "05:00",
        "temp": 24.0,
        "humidity": 97,
        "rain_prob": 43,
        "condition": "partly_cloudy"
      },
      {
        "time": "06:00",
        "temp": 23.8,
        "humidity": 97,
        "rain_prob": 24,
        "condition": "partly_cloudy"
      },
      {
        "time": "07:00",
        "temp": 24.8,
        "humidity": 92,
        "rain_prob": 14,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 25.6,
        "humidity": 88,
        "rain_prob": 24,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 27.8,
        "humidity": 75,
        "rain_prob": 43,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 28.3,
        "humidity": 75,
        "rain_prob": 59,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 29.2,
        "humidity": 71,
        "rain_prob": 66,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 28.8,
        "humidity": 74,
        "rain_prob": 70,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 29.1,
        "humidity": 73,
        "rain_prob": 71,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 29.0,
        "humidity": 73,
        "rain_prob": 69,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 28.6,
        "humidity": 73,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 28.1,
        "humidity": 75,
        "rain_prob": 59,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 27.5,
        "humidity": 77,
        "rain_prob": 49,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 27.0,
        "humidity": 78,
        "rain_prob": 37,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 26.8,
        "humidity": 79,
        "rain_prob": 31,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 26.6,
        "humidity": 80,
        "rain_prob": 35,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 26.3,
        "humidity": 81,
        "rain_prob": 45,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 26.1,
        "humidity": 82,
        "rain_prob": 55,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 25.4,
        "humidity": 86,
        "rain_prob": 64,
        "condition": "sunny"
      }
    ]
  },
  {
    "id": "VN_DN",
    "name": "Đà Nẵng",
    "province": "Đà Nẵng",
    "region": "Miền Trung",
    "type": "Thành phố",
    "lat": 16.0544,
    "lon": 108.2022,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 29.5,
    "feels_like": 34.2,
    "humidity": 66,
    "wind_speed": 11.8,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.8,
    "pressure": 1015,
    "visibility": 14.3,
    "pm25": 10.9,
    "pm10": 14.8,
    "no2": 2.7,
    "co": 0.37,
    "o3": 102.0,
    "so2": 4.0,
    "outdoor_activities": [
      "Đi biển",
      "Chạy bộ",
      "Picnic",
      "Đạp xe",
      "Du lịch"
    ],
    "outdoor_score": 96,
    "best_time": "06:00 - 09:00, 15:30 - 18:30",
    "outdoor_advice": "Thời tiết lý tưởng bậc nhất toàn quốc! Rất phù hợp tắm biển Mỹ Khê, đạp xe cầu Rồng, dã ngoại Sơn Trà.",
    "station_id": "VN_DN",
    "station_name": "Trạm Đà Nẵng",
    "district": "Đà Nẵng",
    "latitude": 16.0544,
    "longitude": 108.2022,
    "temperature": 29.5,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_DN_01",
        "name": "Trạm Hải Châu - Cầu Rồng",
        "type": "Đô thị trung tâm",
        "address": "Đường Bạch Đằng, Q. Hải Châu",
        "lat": 16.062,
        "lon": 108.223,
        "pm25": 11.5,
        "pm10": 17.2,
        "aqi": 21,
        "temp": 29.7,
        "humidity": 64,
        "wind": 12.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DN_02",
        "name": "Trạm Bán đảo Sinh thái Sơn Trà",
        "type": "Trạm nền sinh thái rừng biển",
        "address": "Bán đảo Sơn Trà, Q. Sơn Trà",
        "lat": 16.115,
        "lon": 108.275,
        "pm25": 11.5,
        "pm10": 17.2,
        "aqi": 21,
        "temp": 29.7,
        "humidity": 63,
        "wind": 12.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DN_03",
        "name": "Trạm KCN Hòa Khánh - Liên Chiểu",
        "type": "Công nghiệp",
        "address": "KCN Hòa Khánh, Q. Liên Chiểu",
        "lat": 16.072,
        "lon": 108.145,
        "pm25": 11.5,
        "pm10": 17.2,
        "aqi": 21,
        "temp": 29.7,
        "humidity": 63,
        "wind": 12.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DN_04",
        "name": "Trạm Bãi biển Mỹ Khê",
        "type": "Du lịch ven biển",
        "address": "Đường Võ Nguyên Giáp, Q. Ngũ Hành Sơn",
        "lat": 16.048,
        "lon": 108.245,
        "pm25": 10.9,
        "pm10": 16.4,
        "aqi": 20,
        "temp": 29.5,
        "humidity": 68,
        "wind": 11.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DN",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 26.2,
        "humidity": 90,
        "rain_prob": 53,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 26.5,
        "humidity": 84,
        "rain_prob": 45,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 26.2,
        "humidity": 85,
        "rain_prob": 52,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 25.5,
        "humidity": 87,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 25.6,
        "humidity": 88,
        "rain_prob": 71,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 25.1,
        "humidity": 93,
        "rain_prob": 60,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 25.2,
        "humidity": 94,
        "rain_prob": 42,
        "condition": "overcast"
      },
      {
        "time": "07:00",
        "temp": 25.9,
        "humidity": 88,
        "rain_prob": 31,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 26.9,
        "humidity": 79,
        "rain_prob": 34,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 28.0,
        "humidity": 73,
        "rain_prob": 44,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 28.8,
        "humidity": 70,
        "rain_prob": 49,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 29.4,
        "humidity": 69,
        "rain_prob": 44,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 29.5,
        "humidity": 68,
        "rain_prob": 34,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 29.5,
        "humidity": 66,
        "rain_prob": 27,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 28.8,
        "humidity": 71,
        "rain_prob": 27,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 28.3,
        "humidity": 75,
        "rain_prob": 29,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 28.3,
        "humidity": 74,
        "rain_prob": 29,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 27.9,
        "humidity": 77,
        "rain_prob": 23,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 27.4,
        "humidity": 79,
        "rain_prob": 14,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 27.1,
        "humidity": 80,
        "rain_prob": 14,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 26.5,
        "humidity": 85,
        "rain_prob": 29,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 26.1,
        "humidity": 89,
        "rain_prob": 52,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 25.7,
        "humidity": 91,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 25.0,
        "humidity": 92,
        "rain_prob": 74,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_HCM",
    "name": "Thành phố Hồ Chí Minh",
    "province": "Thành phố Hồ Chí Minh",
    "region": "Miền Nam",
    "type": "Thành phố",
    "lat": 10.7769,
    "lon": 106.7009,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 32.6,
    "feels_like": 38.4,
    "humidity": 56,
    "wind_speed": 8.0,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.6,
    "pressure": 1010,
    "visibility": 13.9,
    "pm25": 16.8,
    "pm10": 18.3,
    "no2": 7.8,
    "co": 0.79,
    "o3": 159.0,
    "so2": 20.3,
    "outdoor_activities": [
      "Đi dạo",
      "Chạy bộ",
      "Picnic",
      "Chụp ảnh"
    ],
    "outdoor_score": 80,
    "best_time": "06:30 - 08:30, 16:30 - 21:00",
    "outdoor_advice": "Buổi trưa nắng gắt (UV 8), nên dạo chơi công viên bờ sông Sài Gòn, phố đi bộ Nguyễn Huệ vào buổi chiều tối.",
    "station_id": "VN_HCM",
    "station_name": "Trạm Thành phố Hồ Chí Minh",
    "district": "Thành phố Hồ Chí Minh",
    "latitude": 10.7769,
    "longitude": 106.7009,
    "temperature": 32.6,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_HCM_01",
        "name": "Trạm Bến Nghé - Quận 1",
        "type": "Đô thị trung tâm hành chính",
        "address": "Đường Nguyễn Huệ, P. Bến Nghé, Q. 1",
        "lat": 10.775,
        "lon": 106.704,
        "pm25": 16.2,
        "pm10": 24.3,
        "aqi": 29,
        "temp": 32.4,
        "humidity": 54,
        "wind": 7.8,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HCM",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HCM_02",
        "name": "Trạm Ngã tư Hàng Xanh - Bình Thạnh",
        "type": "Giao thông mật độ cao",
        "address": "Ngã tư Hàng Xanh, Q. Bình Thạnh",
        "lat": 10.802,
        "lon": 106.712,
        "pm25": 16.2,
        "pm10": 24.3,
        "aqi": 29,
        "temp": 32.4,
        "humidity": 58,
        "wind": 7.8,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HCM",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HCM_03",
        "name": "Trạm TP Thủ Đức - KCNC",
        "type": "Đô thị sáng tạo công nghệ",
        "address": "Đường D1, Khu CNC, TP. Thủ Đức",
        "lat": 10.854,
        "lon": 106.795,
        "pm25": 17.4,
        "pm10": 26.1,
        "aqi": 31,
        "temp": 32.8,
        "humidity": 54,
        "wind": 8.2,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HCM",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HCM_04",
        "name": "Trạm KCN Tân Bình - Bình Chánh",
        "type": "Công nghiệp",
        "address": "KCN Tân Bình & Bình Chánh",
        "lat": 10.812,
        "lon": 106.625,
        "pm25": 18.0,
        "pm10": 27.0,
        "aqi": 32,
        "temp": 33.0,
        "humidity": 58,
        "wind": 8.4,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HCM",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HCM_05",
        "name": "Trạm Sinh thái Cần Giờ",
        "type": "Trạm nền sinh thái rừng ngập mặn",
        "address": "Xã Long Hòa, H. Cần Giờ",
        "lat": 10.415,
        "lon": 106.915,
        "pm25": 16.8,
        "pm10": 25.2,
        "aqi": 30,
        "temp": 32.6,
        "humidity": 59,
        "wind": 8.0,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HCM",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.1,
        "humidity": 95,
        "rain_prob": 26,
        "condition": "overcast"
      },
      {
        "time": "01:00",
        "temp": 26.1,
        "humidity": 87,
        "rain_prob": 12,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 25.5,
        "humidity": 94,
        "rain_prob": 7,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 25.2,
        "humidity": 95,
        "rain_prob": 6,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 24.9,
        "humidity": 94,
        "rain_prob": 6,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 24.5,
        "humidity": 93,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 24.5,
        "humidity": 92,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 25.5,
        "humidity": 88,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 27.0,
        "humidity": 83,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.8,
        "humidity": 75,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 30.2,
        "humidity": 68,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 31.3,
        "humidity": 62,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 32.0,
        "humidity": 59,
        "rain_prob": 3,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 32.8,
        "humidity": 56,
        "rain_prob": 12,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 33.0,
        "humidity": 56,
        "rain_prob": 36,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 32.7,
        "humidity": 57,
        "rain_prob": 67,
        "condition": "overcast"
      },
      {
        "time": "16:00",
        "temp": 26.4,
        "humidity": 93,
        "rain_prob": 86,
        "condition": "thunderstorm"
      },
      {
        "time": "17:00",
        "temp": 26.4,
        "humidity": 89,
        "rain_prob": 83,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.5,
        "humidity": 88,
        "rain_prob": 68,
        "condition": "overcast"
      },
      {
        "time": "19:00",
        "temp": 26.7,
        "humidity": 90,
        "rain_prob": 51,
        "condition": "partly_cloudy"
      },
      {
        "time": "20:00",
        "temp": 26.6,
        "humidity": 89,
        "rain_prob": 34,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 26.5,
        "humidity": 90,
        "rain_prob": 15,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 26.2,
        "humidity": 93,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 25.9,
        "humidity": 94,
        "rain_prob": 0,
        "condition": "sunny"
      }
    ]
  },
  {
    "id": "VN_CT",
    "name": "Cần Thơ",
    "province": "Cần Thơ",
    "region": "Miền Nam",
    "type": "Thành phố",
    "lat": 10.0452,
    "lon": 105.7469,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 31.2,
    "feels_like": 35.3,
    "humidity": 62,
    "wind_speed": 19.4,
    "wind_dir": "Đông",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 7.7,
    "pressure": 1011,
    "visibility": 12.9,
    "pm25": 16.4,
    "pm10": 18.8,
    "no2": 3.8,
    "co": 0.73,
    "o3": 151.0,
    "so2": 15.0,
    "outdoor_activities": [
      "Du lịch",
      "Tham quan",
      "Picnic"
    ],
    "outdoor_score": 88,
    "best_time": "06:00 - 09:30, 16:00 - 19:00",
    "outdoor_advice": "Thời tiết tuyệt vời để tham quan chợ nổi Cái Răng sáng sớm, dạo bến Ninh Kiều về đêm.",
    "station_id": "VN_CT",
    "station_name": "Trạm Cần Thơ",
    "district": "Cần Thơ",
    "latitude": 10.0452,
    "longitude": 105.7469,
    "temperature": 31.2,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_CT_01",
        "name": "Trạm Bến Ninh Kiều - Trung tâm",
        "type": "Đô thị sông nước",
        "address": "Đường Hai Bà Trưng, P. Tân An, Q. Ninh Kiều",
        "lat": 10.035,
        "lon": 105.789,
        "pm25": 15.2,
        "pm10": 22.8,
        "aqi": 27,
        "temp": 30.8,
        "humidity": 65,
        "wind": 19.0,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_CT_02",
        "name": "Trạm KCN Trà Nóc & Cảng Cần Thơ",
        "type": "Công nghiệp cảng",
        "address": "KCN Trà Nóc 1, Q. Bình Thủy",
        "lat": 10.085,
        "lon": 105.725,
        "pm25": 17.6,
        "pm10": 26.4,
        "aqi": 32,
        "temp": 31.6,
        "humidity": 65,
        "wind": 19.8,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_CT_03",
        "name": "Trạm Chợ Nổi Cái Răng",
        "type": "Nông nghiệp du lịch sinh thái",
        "address": "Quận Cái Răng",
        "lat": 10.005,
        "lon": 105.745,
        "pm25": 16.4,
        "pm10": 24.6,
        "aqi": 30,
        "temp": 31.2,
        "humidity": 62,
        "wind": 19.4,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CT",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.6,
        "humidity": 90,
        "rain_prob": 19,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 25.5,
        "humidity": 94,
        "rain_prob": 18,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 24.9,
        "humidity": 94,
        "rain_prob": 19,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 24.7,
        "humidity": 95,
        "rain_prob": 21,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 24.7,
        "humidity": 94,
        "rain_prob": 20,
        "condition": "partly_cloudy"
      },
      {
        "time": "05:00",
        "temp": 24.6,
        "humidity": 95,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 24.6,
        "humidity": 94,
        "rain_prob": 6,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 25.7,
        "humidity": 90,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 27.2,
        "humidity": 82,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 28.5,
        "humidity": 75,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 29.6,
        "humidity": 70,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 30.5,
        "humidity": 65,
        "rain_prob": 13,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 31.0,
        "humidity": 63,
        "rain_prob": 28,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 31.3,
        "humidity": 62,
        "rain_prob": 39,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 31.3,
        "humidity": 63,
        "rain_prob": 45,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 29.6,
        "humidity": 69,
        "rain_prob": 47,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 29.2,
        "humidity": 74,
        "rain_prob": 45,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 28.7,
        "humidity": 78,
        "rain_prob": 35,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 27.9,
        "humidity": 82,
        "rain_prob": 19,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 27.4,
        "humidity": 84,
        "rain_prob": 8,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 27.1,
        "humidity": 85,
        "rain_prob": 5,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 26.5,
        "humidity": 89,
        "rain_prob": 6,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 26.0,
        "humidity": 93,
        "rain_prob": 6,
        "condition": "partly_cloudy"
      },
      {
        "time": "23:00",
        "temp": 25.9,
        "humidity": 94,
        "rain_prob": 4,
        "condition": "partly_cloudy"
      }
    ]
  },
  {
    "id": "VN_CB",
    "name": "Cao Bằng",
    "province": "Cao Bằng",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 22.6667,
    "lon": 106.25,
    "condition": "light_rain",
    "weather_text": "Mưa phùn vừa phải, không khí ẩm",
    "temp": 25.8,
    "feels_like": 29.9,
    "humidity": 79,
    "wind_speed": 5.6,
    "wind_dir": "Đông",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 4.8,
    "pressure": 994,
    "visibility": 13.6,
    "pm25": 5.9,
    "pm10": 7.0,
    "no2": 1.3,
    "co": 0.42,
    "o3": 98.0,
    "so2": 2.1,
    "outdoor_activities": [
      "Leo núi",
      "Du lịch",
      "Chụp ảnh"
    ],
    "outdoor_score": 86,
    "best_time": "09:30 - 15:30",
    "outdoor_advice": "Thời tiết trong trẻo mát lạnh, rất thích hợp check-in thác Bản Giốc, suối Lê-nin; cần áo ấm.",
    "station_id": "VN_CB",
    "station_name": "Trạm Cao Bằng",
    "district": "Cao Bằng",
    "latitude": 22.6667,
    "longitude": 106.25,
    "temperature": 25.8,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_CB_01",
        "name": "Trạm Trung tâm TP Cao Bằng",
        "type": "Đô thị",
        "address": "Đường Kim Đồng, P. Hợp Giang",
        "lat": 22.668,
        "lon": 106.255,
        "pm25": 7.1,
        "pm10": 10.6,
        "aqi": 13,
        "temp": 26.2,
        "humidity": 81,
        "wind": 6.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CB",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_CB_02",
        "name": "Trạm Thác Bản Giốc - Trùng Khánh",
        "type": "Sinh thái du lịch",
        "address": "Xã Đàm Thủy, H. Trùng Khánh",
        "lat": 22.854,
        "lon": 106.723,
        "pm25": 4.7,
        "pm10": 7.1,
        "aqi": 8,
        "temp": 25.4,
        "humidity": 80,
        "wind": 5.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CB",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.4,
        "humidity": 94,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "01:00",
        "temp": 23.0,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "02:00",
        "temp": 22.2,
        "humidity": 93,
        "rain_prob": 21,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.2,
        "humidity": 96,
        "rain_prob": 51,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 22.2,
        "humidity": 97,
        "rain_prob": 71,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.2,
        "humidity": 97,
        "rain_prob": 67,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.3,
        "humidity": 96,
        "rain_prob": 53,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.4,
        "humidity": 96,
        "rain_prob": 47,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 22.7,
        "humidity": 95,
        "rain_prob": 60,
        "condition": "overcast"
      },
      {
        "time": "09:00",
        "temp": 23.6,
        "humidity": 90,
        "rain_prob": 81,
        "condition": "overcast"
      },
      {
        "time": "10:00",
        "temp": 25.2,
        "humidity": 82,
        "rain_prob": 96,
        "condition": "overcast"
      },
      {
        "time": "11:00",
        "temp": 26.2,
        "humidity": 73,
        "rain_prob": 100,
        "condition": "overcast"
      },
      {
        "time": "12:00",
        "temp": 25.5,
        "humidity": 78,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 25.9,
        "humidity": 79,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 26.3,
        "humidity": 76,
        "rain_prob": 95,
        "condition": "overcast"
      },
      {
        "time": "15:00",
        "temp": 24.5,
        "humidity": 87,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 23.1,
        "humidity": 89,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 21.7,
        "humidity": 98,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 21.5,
        "humidity": 99,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 21.3,
        "humidity": 98,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 20.7,
        "humidity": 96,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 19.5,
        "humidity": 95,
        "rain_prob": 97,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 18.7,
        "humidity": 96,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 18.5,
        "humidity": 97,
        "rain_prob": 96,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_TQ",
    "name": "Tuyên Quang",
    "province": "Tuyên Quang",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.8233,
    "lon": 105.2153,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 24.7,
    "feels_like": 29.7,
    "humidity": 91,
    "wind_speed": 3.7,
    "wind_dir": "Tây Bắc",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 6.0,
    "pressure": 1016,
    "visibility": 13.2,
    "pm25": 12.3,
    "pm10": 14.6,
    "no2": 2.1,
    "co": 0.54,
    "o3": 108.0,
    "so2": 7.6,
    "outdoor_activities": [
      "Du lịch",
      "Dã ngoại",
      "Picnic"
    ],
    "outdoor_score": 84,
    "best_time": "08:30 - 16:30",
    "outdoor_advice": "Khí hậu hồ Na Hang mát mẻ, thích hợp du thuyền ngắm cảnh thiên nhiên sơn thủy.",
    "station_id": "VN_TQ",
    "station_name": "Trạm Tuyên Quang",
    "district": "Tuyên Quang",
    "latitude": 21.8233,
    "longitude": 105.2153,
    "temperature": 24.7,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_TQ_01",
        "name": "Trạm Trung tâm TP Tuyên Quang",
        "type": "Đô thị",
        "address": "Đường Tân Trào, P. Phan Thiết",
        "lat": 21.824,
        "lon": 105.217,
        "pm25": 11.7,
        "pm10": 17.5,
        "aqi": 21,
        "temp": 24.5,
        "humidity": 91,
        "wind": 3.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TQ",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TQ_02",
        "name": "Trạm Hồ Sinh thái Na Hang",
        "type": "Trạm nền sinh thái",
        "address": "Thị trấn Na Hang, H. Na Hang",
        "lat": 22.348,
        "lon": 105.385,
        "pm25": 12.3,
        "pm10": 18.5,
        "aqi": 22,
        "temp": 24.7,
        "humidity": 93,
        "wind": 3.7,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TQ",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.2,
        "humidity": 99,
        "rain_prob": 71,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 23.6,
        "humidity": 96,
        "rain_prob": 73,
        "condition": "partly_cloudy"
      },
      {
        "time": "02:00",
        "temp": 22.6,
        "humidity": 98,
        "rain_prob": 81,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.2,
        "humidity": 99,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 22.1,
        "humidity": 98,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.4,
        "humidity": 96,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.0,
        "humidity": 97,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.4,
        "humidity": 96,
        "rain_prob": 76,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 23.0,
        "humidity": 96,
        "rain_prob": 79,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 23.8,
        "humidity": 93,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 24.7,
        "humidity": 91,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 23.1,
        "humidity": 94,
        "rain_prob": 89,
        "condition": "thunderstorm"
      },
      {
        "time": "12:00",
        "temp": 23.7,
        "humidity": 93,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 25.0,
        "humidity": 90,
        "rain_prob": 84,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 25.7,
        "humidity": 85,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 26.0,
        "humidity": 83,
        "rain_prob": 89,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 25.3,
        "humidity": 89,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 24.2,
        "humidity": 96,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 23.8,
        "humidity": 98,
        "rain_prob": 83,
        "condition": "partly_cloudy"
      },
      {
        "time": "19:00",
        "temp": 23.0,
        "humidity": 100,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 22.3,
        "humidity": 99,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 22.0,
        "humidity": 99,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.0,
        "humidity": 99,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.2,
        "humidity": 98,
        "rain_prob": 98,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_DB",
    "name": "Điện Biên",
    "province": "Điện Biên",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.386,
    "lon": 103.023,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 29.4,
    "feels_like": 32.9,
    "humidity": 57,
    "wind_speed": 10.1,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.0,
    "pressure": 964,
    "visibility": 14.6,
    "pm25": 6.1,
    "pm10": 6.4,
    "no2": 1.0,
    "co": 0.46,
    "o3": 85.0,
    "so2": 7.2,
    "outdoor_activities": [
      "Tham quan",
      "Chụp ảnh",
      "Du lịch"
    ],
    "outdoor_score": 90,
    "best_time": "08:00 - 16:00",
    "outdoor_advice": "Trời trong xanh không mưa, hoàn hảo để tham quan di tích Điện Biên Phủ, đồi A1.",
    "station_id": "VN_DB",
    "station_name": "Trạm Điện Biên",
    "district": "Điện Biên",
    "latitude": 21.386,
    "longitude": 103.023,
    "temperature": 29.4,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_DB_01",
        "name": "Trạm Di tích TP Điện Biên Phủ",
        "type": "Đô thị / Văn hóa",
        "address": "Đường Võ Nguyên Giáp, P. Mường Thanh",
        "lat": 21.388,
        "lon": 103.021,
        "pm25": 6.1,
        "pm10": 9.1,
        "aqi": 11,
        "temp": 29.4,
        "humidity": 58,
        "wind": 10.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DB",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DB_02",
        "name": "Trạm Cửa khẩu Tây Trang",
        "type": "Giao thông biên giới",
        "address": "Xã Na Ư, H. Điện Biên",
        "lat": 21.215,
        "lon": 102.915,
        "pm25": 7.3,
        "pm10": 10.9,
        "aqi": 13,
        "temp": 29.8,
        "humidity": 56,
        "wind": 10.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DB",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.0,
        "humidity": 96,
        "rain_prob": 7,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 21.9,
        "humidity": 98,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "02:00",
        "temp": 21.3,
        "humidity": 99,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "03:00",
        "temp": 20.7,
        "humidity": 100,
        "rain_prob": 4,
        "condition": "foggy"
      },
      {
        "time": "04:00",
        "temp": 20.5,
        "humidity": 99,
        "rain_prob": 6,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 20.6,
        "humidity": 98,
        "rain_prob": 6,
        "condition": "foggy"
      },
      {
        "time": "06:00",
        "temp": 20.3,
        "humidity": 99,
        "rain_prob": 5,
        "condition": "foggy"
      },
      {
        "time": "07:00",
        "temp": 20.7,
        "humidity": 97,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 23.1,
        "humidity": 85,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 25.5,
        "humidity": 71,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "10:00",
        "temp": 27.3,
        "humidity": 60,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 28.5,
        "humidity": 57,
        "rain_prob": 17,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 29.2,
        "humidity": 57,
        "rain_prob": 39,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 29.3,
        "humidity": 57,
        "rain_prob": 57,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 28.0,
        "humidity": 61,
        "rain_prob": 71,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 28.5,
        "humidity": 60,
        "rain_prob": 81,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 28.0,
        "humidity": 61,
        "rain_prob": 80,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 26.8,
        "humidity": 65,
        "rain_prob": 58,
        "condition": "partly_cloudy"
      },
      {
        "time": "18:00",
        "temp": 25.3,
        "humidity": 73,
        "rain_prob": 25,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 24.2,
        "humidity": 80,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "20:00",
        "temp": 23.4,
        "humidity": 86,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 22.6,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 22.0,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 21.5,
        "humidity": 94,
        "rain_prob": 2,
        "condition": "sunny"
      }
    ]
  },
  {
    "id": "VN_LC",
    "name": "Lai Châu",
    "province": "Lai Châu",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 22.3964,
    "lon": 103.4589,
    "condition": "partly_cloudy",
    "weather_text": "Mây thay đổi, nắng gián đoạn, thời tiết dễ chịu",
    "temp": 24.3,
    "feels_like": 27.1,
    "humidity": 71,
    "wind_speed": 4.2,
    "wind_dir": "Tây",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 5.4,
    "pressure": 918,
    "visibility": 14.8,
    "pm25": 3.2,
    "pm10": 3.3,
    "no2": 1.0,
    "co": 0.37,
    "o3": 97.0,
    "so2": 8.6,
    "outdoor_activities": [
      "Leo núi",
      "Chụp ảnh"
    ],
    "outdoor_score": 83,
    "best_time": "10:00 - 15:00",
    "outdoor_advice": "Đèo Ô Quy Hồ săn mây tuyệt đẹp, lái xe cần chú ý sương mù ban sáng.",
    "station_id": "VN_LC",
    "station_name": "Trạm Lai Châu",
    "district": "Lai Châu",
    "latitude": 22.3964,
    "longitude": 103.4589,
    "temperature": 24.3,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_LC_01",
        "name": "Trạm Quảng trường TP Lai Châu",
        "type": "Đô thị",
        "address": "Đường Trần Phú, P. Tân Phong",
        "lat": 22.398,
        "lon": 103.461,
        "pm25": 4.4,
        "pm10": 6.6,
        "aqi": 8,
        "temp": 24.7,
        "humidity": 70,
        "wind": 4.6,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LC",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_LC_02",
        "name": "Trạm Đèo Ô Quy Hồ",
        "type": "Trạm nền núi cao",
        "address": "Đèo Ô Quy Hồ, H. Tam Đường",
        "lat": 22.355,
        "lon": 103.778,
        "pm25": 3.2,
        "pm10": 4.8,
        "aqi": 6,
        "temp": 24.3,
        "humidity": 73,
        "wind": 4.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LC",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 18.5,
        "humidity": 98,
        "rain_prob": 73,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 18.5,
        "humidity": 100,
        "rain_prob": 80,
        "condition": "foggy"
      },
      {
        "time": "02:00",
        "temp": 18.0,
        "humidity": 100,
        "rain_prob": 74,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 17.3,
        "humidity": 100,
        "rain_prob": 60,
        "condition": "foggy"
      },
      {
        "time": "04:00",
        "temp": 17.0,
        "humidity": 100,
        "rain_prob": 45,
        "condition": "foggy"
      },
      {
        "time": "05:00",
        "temp": 16.6,
        "humidity": 100,
        "rain_prob": 30,
        "condition": "foggy"
      },
      {
        "time": "06:00",
        "temp": 16.1,
        "humidity": 100,
        "rain_prob": 15,
        "condition": "foggy"
      },
      {
        "time": "07:00",
        "temp": 16.5,
        "humidity": 100,
        "rain_prob": 4,
        "condition": "foggy"
      },
      {
        "time": "08:00",
        "temp": 19.0,
        "humidity": 99,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 21.0,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "10:00",
        "temp": 22.8,
        "humidity": 76,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "11:00",
        "temp": 23.6,
        "humidity": 73,
        "rain_prob": 7,
        "condition": "partly_cloudy"
      },
      {
        "time": "12:00",
        "temp": 24.2,
        "humidity": 71,
        "rain_prob": 18,
        "condition": "overcast"
      },
      {
        "time": "13:00",
        "temp": 24.3,
        "humidity": 70,
        "rain_prob": 31,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 24.8,
        "humidity": 69,
        "rain_prob": 48,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 23.5,
        "humidity": 74,
        "rain_prob": 67,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 22.0,
        "humidity": 85,
        "rain_prob": 76,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 21.3,
        "humidity": 93,
        "rain_prob": 67,
        "condition": "overcast"
      },
      {
        "time": "18:00",
        "temp": 20.3,
        "humidity": 95,
        "rain_prob": 48,
        "condition": "overcast"
      },
      {
        "time": "19:00",
        "temp": 20.2,
        "humidity": 94,
        "rain_prob": 31,
        "condition": "overcast"
      },
      {
        "time": "20:00",
        "temp": 20.3,
        "humidity": 91,
        "rain_prob": 18,
        "condition": "overcast"
      },
      {
        "time": "21:00",
        "temp": 20.4,
        "humidity": 88,
        "rain_prob": 7,
        "condition": "overcast"
      },
      {
        "time": "22:00",
        "temp": 20.1,
        "humidity": 87,
        "rain_prob": 4,
        "condition": "overcast"
      },
      {
        "time": "23:00",
        "temp": 19.7,
        "humidity": 89,
        "rain_prob": 14,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_SL",
    "name": "Sơn La",
    "province": "Sơn La",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.3283,
    "lon": 103.9148,
    "condition": "sunny",
    "weather_text": "Trời trong xanh, ít mây, nắng dịu",
    "temp": 25.5,
    "feels_like": 28.5,
    "humidity": 77,
    "wind_speed": 11.9,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.2,
    "pressure": 952,
    "visibility": 14.6,
    "pm25": 5.7,
    "pm10": 6.1,
    "no2": 1.5,
    "co": 0.46,
    "o3": 93.0,
    "so2": 11.4,
    "outdoor_activities": [
      "Picnic",
      "Chụp ảnh",
      "Du lịch"
    ],
    "outdoor_score": 94,
    "best_time": "08:00 - 16:30",
    "outdoor_advice": "Mộc Châu mùa này hoa nở tuyệt đẹp, nắng nhẹ mát mẻ, cực kỳ lý tưởng cắm trại đồi chè.",
    "station_id": "VN_SL",
    "station_name": "Trạm Sơn La",
    "district": "Sơn La",
    "latitude": 21.3283,
    "longitude": 103.9148,
    "temperature": 25.5,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_SL_01",
        "name": "Trạm Trung tâm TP Sơn La",
        "type": "Đô thị",
        "address": "Đường Tô Hiệu, P. Chiềng Lề",
        "lat": 21.33,
        "lon": 103.918,
        "pm25": 5.7,
        "pm10": 8.6,
        "aqi": 10,
        "temp": 25.5,
        "humidity": 79,
        "wind": 11.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_SL",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_SL_02",
        "name": "Trạm Cao nguyên Mộc Châu",
        "type": "Sinh thái nông nghiệp",
        "address": "Thị trấn Nông trường Mộc Châu",
        "lat": 20.842,
        "lon": 104.654,
        "pm25": 6.3,
        "pm10": 9.4,
        "aqi": 11,
        "temp": 25.7,
        "humidity": 79,
        "wind": 12.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_SL",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 21.1,
        "humidity": 94,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 21.1,
        "humidity": 95,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "02:00",
        "temp": 20.5,
        "humidity": 95,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "03:00",
        "temp": 20.1,
        "humidity": 96,
        "rain_prob": 1,
        "condition": "partly_cloudy"
      },
      {
        "time": "04:00",
        "temp": 20.0,
        "humidity": 97,
        "rain_prob": 2,
        "condition": "partly_cloudy"
      },
      {
        "time": "05:00",
        "temp": 20.2,
        "humidity": 97,
        "rain_prob": 1,
        "condition": "partly_cloudy"
      },
      {
        "time": "06:00",
        "temp": 20.5,
        "humidity": 97,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 21.0,
        "humidity": 95,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 22.0,
        "humidity": 88,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 23.2,
        "humidity": 81,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "10:00",
        "temp": 25.1,
        "humidity": 72,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 23.9,
        "humidity": 81,
        "rain_prob": 30,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 25.2,
        "humidity": 79,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 25.5,
        "humidity": 77,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 25.2,
        "humidity": 76,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 24.9,
        "humidity": 78,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 24.8,
        "humidity": 76,
        "rain_prob": 65,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 23.9,
        "humidity": 78,
        "rain_prob": 44,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 22.6,
        "humidity": 80,
        "rain_prob": 18,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 22.1,
        "humidity": 83,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 21.7,
        "humidity": 85,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 21.0,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 20.9,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "23:00",
        "temp": 20.8,
        "humidity": 89,
        "rain_prob": 5,
        "condition": "partly_cloudy"
      }
    ]
  },
  {
    "id": "VN_LCAI",
    "name": "Lào Cai",
    "province": "Lào Cai",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 22.4856,
    "lon": 103.9707,
    "condition": "partly_cloudy",
    "weather_text": "Mây thay đổi, nắng gián đoạn, thời tiết dễ chịu",
    "temp": 26.3,
    "feels_like": 30.2,
    "humidity": 75,
    "wind_speed": 6.6,
    "wind_dir": "Nam",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 5.5,
    "pressure": 1009,
    "visibility": 14.6,
    "pm25": 5.5,
    "pm10": 5.9,
    "no2": 1.4,
    "co": 0.5,
    "o3": 95.0,
    "so2": 13.5,
    "outdoor_activities": [
      "Leo núi",
      "Chụp ảnh",
      "Du lịch"
    ],
    "outdoor_score": 85,
    "best_time": "10:00 - 15:30",
    "outdoor_advice": "Sa Pa mờ sương lãng mạn, thích hợp chinh phục đỉnh Fansipan và bản Cát Cát.",
    "station_id": "VN_LCAI",
    "station_name": "Trạm Lào Cai",
    "district": "Lào Cai",
    "latitude": 22.4856,
    "longitude": 103.9707,
    "temperature": 26.3,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_LCAI_01",
        "name": "Trạm TP Lào Cai - Cửa khẩu",
        "type": "Đô thị biên giới",
        "address": "Đường Hoàng Liên, P. Cốc Lếu",
        "lat": 22.489,
        "lon": 103.968,
        "pm25": 4.3,
        "pm10": 6.4,
        "aqi": 8,
        "temp": 25.9,
        "humidity": 74,
        "wind": 6.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LCAI",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_LCAI_02",
        "name": "Trạm Sa Pa - Đỉnh Fansipan",
        "type": "Sinh thái núi cao",
        "address": "Thị xã Sa Pa",
        "lat": 22.336,
        "lon": 103.844,
        "pm25": 6.7,
        "pm10": 10.1,
        "aqi": 12,
        "temp": 26.7,
        "humidity": 74,
        "wind": 7.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LCAI",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.2,
        "humidity": 97,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 22.6,
        "humidity": 96,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 22.4,
        "humidity": 95,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 21.9,
        "humidity": 98,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 21.4,
        "humidity": 98,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 21.9,
        "humidity": 96,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.1,
        "humidity": 95,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.6,
        "humidity": 94,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 22.7,
        "humidity": 94,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 23.1,
        "humidity": 93,
        "rain_prob": 67,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 23.9,
        "humidity": 86,
        "rain_prob": 55,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 25.3,
        "humidity": 78,
        "rain_prob": 50,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 25.7,
        "humidity": 78,
        "rain_prob": 48,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.4,
        "humidity": 75,
        "rain_prob": 49,
        "condition": "partly_cloudy"
      },
      {
        "time": "14:00",
        "temp": 26.2,
        "humidity": 77,
        "rain_prob": 55,
        "condition": "overcast"
      },
      {
        "time": "15:00",
        "temp": 26.1,
        "humidity": 79,
        "rain_prob": 64,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 26.0,
        "humidity": 80,
        "rain_prob": 71,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 25.4,
        "humidity": 86,
        "rain_prob": 71,
        "condition": "partly_cloudy"
      },
      {
        "time": "18:00",
        "temp": 24.6,
        "humidity": 87,
        "rain_prob": 68,
        "condition": "overcast"
      },
      {
        "time": "19:00",
        "temp": 24.0,
        "humidity": 93,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 22.3,
        "humidity": 97,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 21.7,
        "humidity": 98,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.0,
        "humidity": 96,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.1,
        "humidity": 94,
        "rain_prob": 99,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_TN",
    "name": "Thái Nguyên",
    "province": "Thái Nguyên",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.5942,
    "lon": 105.8482,
    "condition": "light_rain",
    "weather_text": "Mưa phùn vừa phải, không khí ẩm",
    "temp": 26.8,
    "feels_like": 31.4,
    "humidity": 80,
    "wind_speed": 6.0,
    "wind_dir": "Đông Nam",
    "rain_prob": 7,
    "rain_mm": 0.0,
    "uv": 5.3,
    "pressure": 1014,
    "visibility": 14.4,
    "pm25": 9.0,
    "pm10": 9.5,
    "no2": 4.8,
    "co": 0.59,
    "o3": 107.0,
    "so2": 17.9,
    "outdoor_activities": [
      "Dã ngoại",
      "Tham quan"
    ],
    "outdoor_score": 75,
    "best_time": "08:30 - 11:00, 15:00 - 17:00",
    "outdoor_advice": "Thích hợp dã ngoại hồ Núi Cốc, tham quan vùng chè Tân Cương.",
    "station_id": "VN_TN",
    "station_name": "Trạm Thái Nguyên",
    "district": "Thái Nguyên",
    "latitude": 21.5942,
    "longitude": 105.8482,
    "temperature": 26.8,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_TN_01",
        "name": "Trạm Trung tâm TP Thái Nguyên",
        "type": "Đô thị",
        "address": "Đường Lương Ngọc Quyến, P. Quang Trung",
        "lat": 21.596,
        "lon": 105.845,
        "pm25": 9.0,
        "pm10": 13.5,
        "aqi": 16,
        "temp": 26.8,
        "humidity": 77,
        "wind": 6.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TN_02",
        "name": "Trạm KCN Yên Bình (Samsung)",
        "type": "Công nghiệp",
        "address": "Phường Đồng Tiến, TX. Phổ Yên",
        "lat": 21.432,
        "lon": 105.885,
        "pm25": 8.4,
        "pm10": 12.6,
        "aqi": 15,
        "temp": 26.6,
        "humidity": 82,
        "wind": 5.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TN_03",
        "name": "Trạm Sinh thái Hồ Núi Cốc",
        "type": "Trạm nền sinh thái",
        "address": "Xã Tân Thái, H. Đại Từ",
        "lat": 21.602,
        "lon": 105.715,
        "pm25": 10.2,
        "pm10": 15.3,
        "aqi": 18,
        "temp": 27.2,
        "humidity": 81,
        "wind": 6.4,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TN",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 23.0,
        "humidity": 98,
        "rain_prob": 45,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 22.9,
        "humidity": 98,
        "rain_prob": 47,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 23.0,
        "humidity": 97,
        "rain_prob": 63,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.4,
        "humidity": 96,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 22.5,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.2,
        "humidity": 98,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.3,
        "humidity": 98,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.4,
        "humidity": 97,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 22.8,
        "humidity": 96,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 23.8,
        "humidity": 93,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 25.8,
        "humidity": 88,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 28.0,
        "humidity": 76,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 28.4,
        "humidity": 73,
        "rain_prob": 83,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.3,
        "humidity": 83,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 25.6,
        "humidity": 86,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 26.1,
        "humidity": 82,
        "rain_prob": 95,
        "condition": "partly_cloudy"
      },
      {
        "time": "16:00",
        "temp": 24.6,
        "humidity": 89,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 24.0,
        "humidity": 94,
        "rain_prob": 97,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 23.8,
        "humidity": 95,
        "rain_prob": 90,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 23.5,
        "humidity": 95,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 22.3,
        "humidity": 99,
        "rain_prob": 89,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 22.4,
        "humidity": 97,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.6,
        "humidity": 95,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.1,
        "humidity": 88,
        "rain_prob": 100,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_LS",
    "name": "Lạng Sơn",
    "province": "Lạng Sơn",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.8533,
    "lon": 106.7583,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 25.6,
    "feels_like": 29.4,
    "humidity": 81,
    "wind_speed": 9.3,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 4.5,
    "pressure": 990,
    "visibility": 14.7,
    "pm25": 4.6,
    "pm10": 5.7,
    "no2": 1.8,
    "co": 0.43,
    "o3": 93.0,
    "so2": 3.2,
    "outdoor_activities": [
      "Tham quan",
      "Mua sắm",
      "Du lịch"
    ],
    "outdoor_score": 85,
    "best_time": "08:30 - 16:30",
    "outdoor_advice": "Thời tiết khô ráo, thuận lợi vãn cảnh chùa Tam Thanh và đỉnh Mẫu Sơn.",
    "station_id": "VN_LS",
    "station_name": "Trạm Lạng Sơn",
    "district": "Lạng Sơn",
    "latitude": 21.8533,
    "longitude": 106.7583,
    "temperature": 25.6,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_LS_01",
        "name": "Trạm TP Lạng Sơn - Tam Thanh",
        "type": "Đô thị",
        "address": "Đường Lê Lợi, P. Vĩnh Trại",
        "lat": 21.855,
        "lon": 106.76,
        "pm25": 4.6,
        "pm10": 6.9,
        "aqi": 8,
        "temp": 25.6,
        "humidity": 80,
        "wind": 9.3,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LS",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_LS_02",
        "name": "Trạm Cửa khẩu Quốc tế Hữu Nghị",
        "type": "Giao thông biên giới",
        "address": "Thị trấn Đồng Đăng, H. Cao Lộc",
        "lat": 21.985,
        "lon": 106.712,
        "pm25": 5.2,
        "pm10": 7.8,
        "aqi": 9,
        "temp": 25.8,
        "humidity": 80,
        "wind": 9.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LS",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_LS_03",
        "name": "Trạm Khí tượng Đỉnh Mẫu Sơn",
        "type": "Trạm nền núi cao",
        "address": "Khu du lịch Mẫu Sơn, H. Lộc Bình",
        "lat": 21.848,
        "lon": 106.915,
        "pm25": 5.8,
        "pm10": 8.7,
        "aqi": 10,
        "temp": 26.0,
        "humidity": 82,
        "wind": 9.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LS",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 21.2,
        "humidity": 98,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "01:00",
        "temp": 22.8,
        "humidity": 97,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 22.3,
        "humidity": 96,
        "rain_prob": 18,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 21.9,
        "humidity": 96,
        "rain_prob": 41,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 21.3,
        "humidity": 98,
        "rain_prob": 53,
        "condition": "partly_cloudy"
      },
      {
        "time": "05:00",
        "temp": 21.4,
        "humidity": 98,
        "rain_prob": 41,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 21.4,
        "humidity": 98,
        "rain_prob": 18,
        "condition": "overcast"
      },
      {
        "time": "07:00",
        "temp": 21.6,
        "humidity": 97,
        "rain_prob": 2,
        "condition": "overcast"
      },
      {
        "time": "08:00",
        "temp": 22.6,
        "humidity": 91,
        "rain_prob": 1,
        "condition": "overcast"
      },
      {
        "time": "09:00",
        "temp": 24.2,
        "humidity": 81,
        "rain_prob": 7,
        "condition": "overcast"
      },
      {
        "time": "10:00",
        "temp": 25.4,
        "humidity": 76,
        "rain_prob": 18,
        "condition": "overcast"
      },
      {
        "time": "11:00",
        "temp": 25.6,
        "humidity": 75,
        "rain_prob": 37,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 23.6,
        "humidity": 89,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.0,
        "humidity": 79,
        "rain_prob": 80,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 23.9,
        "humidity": 87,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 24.3,
        "humidity": 85,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 22.8,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 22.3,
        "humidity": 98,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 21.8,
        "humidity": 98,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 21.5,
        "humidity": 98,
        "rain_prob": 47,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 20.2,
        "humidity": 97,
        "rain_prob": 51,
        "condition": "overcast"
      },
      {
        "time": "21:00",
        "temp": 20.3,
        "humidity": 96,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 20.2,
        "humidity": 96,
        "rain_prob": 75,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 18.9,
        "humidity": 95,
        "rain_prob": 79,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_QN",
    "name": "Quảng Ninh",
    "province": "Quảng Ninh",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 20.9505,
    "lon": 107.0734,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 28.5,
    "feels_like": 31.3,
    "humidity": 69,
    "wind_speed": 20.0,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.2,
    "pressure": 1018,
    "visibility": 14.5,
    "pm25": 7.3,
    "pm10": 9.0,
    "no2": 1.8,
    "co": 0.44,
    "o3": 119.0,
    "so2": 5.4,
    "outdoor_activities": [
      "Đi biển",
      "Du lịch",
      "Chụp ảnh",
      "Đi dạo"
    ],
    "outdoor_score": 95,
    "best_time": "07:30 - 11:30, 14:00 - 17:30",
    "outdoor_advice": "Vịnh Hạ Long sóng êm biển lặng, trời trong xanh hoàn hảo cho tour du thuyền, ngắm hoàng hôn.",
    "station_id": "VN_QN",
    "station_name": "Trạm Quảng Ninh",
    "district": "Quảng Ninh",
    "latitude": 20.9505,
    "longitude": 107.0734,
    "temperature": 28.5,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_QN_01",
        "name": "Trạm Bãi Cháy - Hạ Long",
        "type": "Đô thị du lịch ven biển",
        "address": "Đường Hạ Long, P. Bãi Cháy",
        "lat": 20.958,
        "lon": 107.035,
        "pm25": 7.9,
        "pm10": 11.9,
        "aqi": 14,
        "temp": 28.7,
        "humidity": 68,
        "wind": 20.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_QN_02",
        "name": "Trạm Cẩm Phả - Vùng khai thác",
        "type": "Công nghiệp khai khoáng",
        "address": "Đường Trần Phú, P. Cẩm Thành",
        "lat": 21.018,
        "lon": 107.288,
        "pm25": 6.7,
        "pm10": 10.1,
        "aqi": 12,
        "temp": 28.3,
        "humidity": 69,
        "wind": 19.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_QN_03",
        "name": "Trạm Vân Đồn - Sân bay & Đảo",
        "type": "Sinh thái biển đảo",
        "address": "Huyện Vân Đồn",
        "lat": 21.125,
        "lon": 107.412,
        "pm25": 6.7,
        "pm10": 10.1,
        "aqi": 12,
        "temp": 28.3,
        "humidity": 67,
        "wind": 19.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QN",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.1,
        "humidity": 83,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 24.9,
        "humidity": 87,
        "rain_prob": 8,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 24.0,
        "humidity": 94,
        "rain_prob": 17,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 24.0,
        "humidity": 91,
        "rain_prob": 28,
        "condition": "partly_cloudy"
      },
      {
        "time": "04:00",
        "temp": 23.8,
        "humidity": 91,
        "rain_prob": 33,
        "condition": "partly_cloudy"
      },
      {
        "time": "05:00",
        "temp": 23.7,
        "humidity": 90,
        "rain_prob": 28,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 23.4,
        "humidity": 88,
        "rain_prob": 18,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 24.2,
        "humidity": 83,
        "rain_prob": 10,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 25.6,
        "humidity": 77,
        "rain_prob": 3,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 27.0,
        "humidity": 73,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 27.6,
        "humidity": 71,
        "rain_prob": 4,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 27.9,
        "humidity": 70,
        "rain_prob": 31,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 27.8,
        "humidity": 73,
        "rain_prob": 68,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 28.7,
        "humidity": 68,
        "rain_prob": 92,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 28.2,
        "humidity": 71,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 27.7,
        "humidity": 73,
        "rain_prob": 76,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 27.4,
        "humidity": 74,
        "rain_prob": 59,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 26.5,
        "humidity": 78,
        "rain_prob": 38,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 25.9,
        "humidity": 81,
        "rain_prob": 15,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 25.8,
        "humidity": 81,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 25.5,
        "humidity": 82,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.2,
        "humidity": 82,
        "rain_prob": 35,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 23.6,
        "humidity": 91,
        "rain_prob": 55,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.5,
        "humidity": 94,
        "rain_prob": 70,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_BN",
    "name": "Bắc Ninh",
    "province": "Bắc Ninh",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.1861,
    "lon": 106.0763,
    "condition": "partly_cloudy",
    "weather_text": "Mây thay đổi, nắng gián đoạn, thời tiết dễ chịu",
    "temp": 28.5,
    "feels_like": 32.8,
    "humidity": 70,
    "wind_speed": 6.4,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 5.7,
    "pressure": 1017,
    "visibility": 14.3,
    "pm25": 11.0,
    "pm10": 11.6,
    "no2": 6.0,
    "co": 0.5,
    "o3": 113.0,
    "so2": 19.0,
    "outdoor_activities": [
      "Tham quan di tích"
    ],
    "outdoor_score": 72,
    "best_time": "09:00 - 11:00",
    "outdoor_advice": "Bụi mịn ở mức Kém do phát thải công nghiệp; nên đeo khẩu trang khi nghe Quan họ đền Đô.",
    "station_id": "VN_BN",
    "station_name": "Trạm Bắc Ninh",
    "district": "Bắc Ninh",
    "latitude": 21.1861,
    "longitude": 106.0763,
    "temperature": 28.5,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_BN_01",
        "name": "Trạm TP Bắc Ninh - Đền Đô",
        "type": "Đô thị văn hóa",
        "address": "Đường Ngô Gia Tự, P. Tiền An",
        "lat": 21.189,
        "lon": 106.072,
        "pm25": 12.2,
        "pm10": 18.3,
        "aqi": 22,
        "temp": 28.9,
        "humidity": 70,
        "wind": 6.8,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_BN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_BN_02",
        "name": "Trạm KCN Quế Võ",
        "type": "Công nghiệp",
        "address": "KCN Quế Võ, TX. Quế Võ",
        "lat": 21.162,
        "lon": 106.145,
        "pm25": 9.8,
        "pm10": 14.7,
        "aqi": 18,
        "temp": 28.1,
        "humidity": 67,
        "wind": 6.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_BN",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_BN_03",
        "name": "Trạm KCN Yên Phong",
        "type": "Công nghiệp công nghệ cao",
        "address": "KCN Yên Phong, H. Yên Phong",
        "lat": 21.225,
        "lon": 105.985,
        "pm25": 10.4,
        "pm10": 15.6,
        "aqi": 19,
        "temp": 28.3,
        "humidity": 68,
        "wind": 6.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_BN",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.0,
        "humidity": 91,
        "rain_prob": 53,
        "condition": "overcast"
      },
      {
        "time": "01:00",
        "temp": 23.1,
        "humidity": 97,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 22.5,
        "humidity": 97,
        "rain_prob": 82,
        "condition": "thunderstorm"
      },
      {
        "time": "03:00",
        "temp": 22.5,
        "humidity": 97,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 22.3,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.1,
        "humidity": 98,
        "rain_prob": 97,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.2,
        "humidity": 98,
        "rain_prob": 89,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.7,
        "humidity": 97,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 23.8,
        "humidity": 91,
        "rain_prob": 62,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 25.8,
        "humidity": 82,
        "rain_prob": 43,
        "condition": "partly_cloudy"
      },
      {
        "time": "10:00",
        "temp": 27.6,
        "humidity": 75,
        "rain_prob": 35,
        "condition": "overcast"
      },
      {
        "time": "11:00",
        "temp": 28.3,
        "humidity": 72,
        "rain_prob": 46,
        "condition": "overcast"
      },
      {
        "time": "12:00",
        "temp": 28.3,
        "humidity": 71,
        "rain_prob": 67,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 28.2,
        "humidity": 72,
        "rain_prob": 84,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 24.2,
        "humidity": 91,
        "rain_prob": 93,
        "condition": "thunderstorm"
      },
      {
        "time": "15:00",
        "temp": 24.5,
        "humidity": 90,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 25.0,
        "humidity": 88,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 24.5,
        "humidity": 89,
        "rain_prob": 97,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 24.0,
        "humidity": 92,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 22.6,
        "humidity": 96,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 22.7,
        "humidity": 98,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 23.3,
        "humidity": 94,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 23.0,
        "humidity": 90,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.5,
        "humidity": 90,
        "rain_prob": 92,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_PT",
    "name": "Phú Thọ",
    "province": "Phú Thọ",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 21.3228,
    "lon": 105.228,
    "condition": "overcast",
    "weather_text": "Trời nhiều mây, âm u, không khí mát mẻ",
    "temp": 26.4,
    "feels_like": 31.5,
    "humidity": 79,
    "wind_speed": 4.1,
    "wind_dir": "Tây Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.0,
    "pressure": 1015,
    "visibility": 14.0,
    "pm25": 14.9,
    "pm10": 15.8,
    "no2": 6.3,
    "co": 0.5,
    "o3": 110.0,
    "so2": 22.4,
    "outdoor_activities": [
      "Tham quan",
      "Đi dạo"
    ],
    "outdoor_score": 86,
    "best_time": "08:00 - 11:30, 14:30 - 17:00",
    "outdoor_advice": "Thời tiết trong lành mát dịu, rất thuận lợi dâng hương Đền Hùng.",
    "station_id": "VN_PT",
    "station_name": "Trạm Phú Thọ",
    "district": "Phú Thọ",
    "latitude": 21.3228,
    "longitude": 105.228,
    "temperature": 26.4,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_PT_01",
        "name": "Trạm TP Việt Trì - Trung tâm",
        "type": "Đô thị",
        "address": "Đường Hùng Vương, P. Gia Cẩm",
        "lat": 21.318,
        "lon": 105.412,
        "pm25": 15.5,
        "pm10": 23.2,
        "aqi": 28,
        "temp": 26.6,
        "humidity": 79,
        "wind": 4.3,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_PT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_PT_02",
        "name": "Trạm Khu Di tích Đền Hùng",
        "type": "Trạm nền văn hóa lịch sử",
        "address": "Khu di tích lịch sử Đền Hùng",
        "lat": 21.378,
        "lon": 105.335,
        "pm25": 14.9,
        "pm10": 22.4,
        "aqi": 27,
        "temp": 26.4,
        "humidity": 77,
        "wind": 4.1,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_PT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_PT_03",
        "name": "Trạm KCN Thụy Vân",
        "type": "Công nghiệp",
        "address": "KCN Thụy Vân, TP. Việt Trì",
        "lat": 21.345,
        "lon": 105.378,
        "pm25": 14.3,
        "pm10": 21.5,
        "aqi": 26,
        "temp": 26.2,
        "humidity": 80,
        "wind": 3.9,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_PT",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.2,
        "humidity": 97,
        "rain_prob": 78,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 22.2,
        "humidity": 98,
        "rain_prob": 78,
        "condition": "partly_cloudy"
      },
      {
        "time": "02:00",
        "temp": 21.6,
        "humidity": 97,
        "rain_prob": 84,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 21.2,
        "humidity": 97,
        "rain_prob": 94,
        "condition": "thunderstorm"
      },
      {
        "time": "04:00",
        "temp": 21.5,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 21.2,
        "humidity": 98,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 21.0,
        "humidity": 100,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 21.4,
        "humidity": 97,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 22.5,
        "humidity": 93,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 23.5,
        "humidity": 89,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 23.9,
        "humidity": 87,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 24.2,
        "humidity": 89,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 25.0,
        "humidity": 86,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.8,
        "humidity": 78,
        "rain_prob": 90,
        "condition": "overcast"
      },
      {
        "time": "14:00",
        "temp": 27.2,
        "humidity": 75,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 26.7,
        "humidity": 76,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 25.2,
        "humidity": 82,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 24.3,
        "humidity": 90,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 23.5,
        "humidity": 96,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 22.5,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 22.6,
        "humidity": 95,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 22.1,
        "humidity": 96,
        "rain_prob": 97,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.0,
        "humidity": 98,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.5,
        "humidity": 93,
        "rain_prob": 97,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_HY",
    "name": "Hưng Yên",
    "province": "Hưng Yên",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 20.6464,
    "lon": 106.0511,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 26.7,
    "feels_like": 32.5,
    "humidity": 86,
    "wind_speed": 2.2,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 5.9,
    "pressure": 1016,
    "visibility": 14.1,
    "pm25": 13.8,
    "pm10": 14.8,
    "no2": 13.7,
    "co": 0.59,
    "o3": 100.0,
    "so2": 27.0,
    "outdoor_activities": [
      "Đi dạo",
      "Chụp ảnh"
    ],
    "outdoor_score": 79,
    "best_time": "08:30 - 11:00, 15:00 - 17:30",
    "outdoor_advice": "Khám phá Phố Hiến, hồ Bán Nguyệt cổ kính, thời tiết dễ chịu.",
    "station_id": "VN_HY",
    "station_name": "Trạm Hưng Yên",
    "district": "Hưng Yên",
    "latitude": 20.6464,
    "longitude": 106.0511,
    "temperature": 26.7,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_HY_01",
        "name": "Trạm TP Hưng Yên - Phố Hiến",
        "type": "Đô thị cổ",
        "address": "Đường Bãi Sậy, P. Quang Trung",
        "lat": 20.648,
        "lon": 106.053,
        "pm25": 14.4,
        "pm10": 21.6,
        "aqi": 26,
        "temp": 26.9,
        "humidity": 86,
        "wind": 2.4,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HY",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HY_02",
        "name": "Trạm KCN Phố Nối A",
        "type": "Công nghiệp",
        "address": "Huyện Văn Lâm & Mỹ Hào",
        "lat": 20.935,
        "lon": 106.035,
        "pm25": 14.4,
        "pm10": 21.6,
        "aqi": 26,
        "temp": 26.9,
        "humidity": 88,
        "wind": 2.4,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HY",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HY_03",
        "name": "Trạm Sinh thái Ecopark",
        "type": "Đô thị sinh thái",
        "address": "Khu đô thị Ecopark, Văn Giang",
        "lat": 20.965,
        "lon": 105.932,
        "pm25": 13.2,
        "pm10": 19.8,
        "aqi": 24,
        "temp": 26.5,
        "humidity": 84,
        "wind": 2.0,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HY",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 23.4,
        "humidity": 95,
        "rain_prob": 82,
        "condition": "thunderstorm"
      },
      {
        "time": "01:00",
        "temp": 23.8,
        "humidity": 98,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 22.7,
        "humidity": 99,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.6,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 22.6,
        "humidity": 95,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.8,
        "humidity": 94,
        "rain_prob": 93,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.7,
        "humidity": 96,
        "rain_prob": 83,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 23.2,
        "humidity": 94,
        "rain_prob": 73,
        "condition": "overcast"
      },
      {
        "time": "08:00",
        "temp": 23.7,
        "humidity": 92,
        "rain_prob": 62,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 25.3,
        "humidity": 85,
        "rain_prob": 50,
        "condition": "overcast"
      },
      {
        "time": "10:00",
        "temp": 26.6,
        "humidity": 81,
        "rain_prob": 47,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 28.2,
        "humidity": 73,
        "rain_prob": 59,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 26.6,
        "humidity": 85,
        "rain_prob": 79,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.9,
        "humidity": 84,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 28.0,
        "humidity": 76,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 26.6,
        "humidity": 79,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 25.3,
        "humidity": 85,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 25.0,
        "humidity": 90,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 23.5,
        "humidity": 95,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 23.2,
        "humidity": 95,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 23.2,
        "humidity": 95,
        "rain_prob": 93,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 23.1,
        "humidity": 94,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.5,
        "humidity": 96,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 23.0,
        "humidity": 93,
        "rain_prob": 94,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_NB",
    "name": "Ninh Bình",
    "province": "Ninh Bình",
    "region": "Miền Bắc",
    "type": "Tỉnh",
    "lat": 20.2506,
    "lon": 105.9744,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 26.3,
    "feels_like": 30.1,
    "humidity": 82,
    "wind_speed": 12.0,
    "wind_dir": "Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 5.3,
    "pressure": 1017,
    "visibility": 14.2,
    "pm25": 12.4,
    "pm10": 14.5,
    "no2": 11.2,
    "co": 0.56,
    "o3": 98.0,
    "so2": 18.0,
    "outdoor_activities": [
      "Du lịch",
      "Đi thuyền",
      "Chụp ảnh",
      "Leo núi"
    ],
    "outdoor_score": 95,
    "best_time": "07:30 - 11:30, 14:00 - 17:30",
    "outdoor_advice": "Thời tiết tuyệt mỹ! Chèo thuyền Tràng An, Tam Cốc hoặc leo đỉnh Hang Múa ngắm cảnh cực đẹp.",
    "station_id": "VN_NB",
    "station_name": "Trạm Ninh Bình",
    "district": "Ninh Bình",
    "latitude": 20.2506,
    "longitude": 105.9744,
    "temperature": 26.3,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_NB_01",
        "name": "Trạm Trung tâm TP Ninh Bình",
        "type": "Đô thị",
        "address": "Đường Lê Thái Tổ, P. Đông Thành",
        "lat": 20.255,
        "lon": 105.978,
        "pm25": 11.2,
        "pm10": 16.8,
        "aqi": 20,
        "temp": 25.9,
        "humidity": 82,
        "wind": 11.6,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_NB",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_NB_02",
        "name": "Trạm Di sản Tràng An - Tam Cốc",
        "type": "Trạm nền di sản thiên nhiên",
        "address": "Quần thể danh thắng Tràng An",
        "lat": 20.258,
        "lon": 105.908,
        "pm25": 12.4,
        "pm10": 18.6,
        "aqi": 22,
        "temp": 26.3,
        "humidity": 79,
        "wind": 12.0,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_NB",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_NB_03",
        "name": "Trạm KCN Gián Khẩu",
        "type": "Công nghiệp",
        "address": "Huyện Gia Viễn",
        "lat": 20.325,
        "lon": 105.912,
        "pm25": 11.8,
        "pm10": 17.7,
        "aqi": 21,
        "temp": 26.1,
        "humidity": 84,
        "wind": 11.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_NB",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.7,
        "humidity": 99,
        "rain_prob": 98,
        "condition": "thunderstorm"
      },
      {
        "time": "01:00",
        "temp": 22.8,
        "humidity": 95,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 22.7,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.8,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 22.6,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "sunny"
      },
      {
        "time": "05:00",
        "temp": 22.5,
        "humidity": 98,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 22.7,
        "humidity": 95,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.7,
        "humidity": 94,
        "rain_prob": 51,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 23.3,
        "humidity": 91,
        "rain_prob": 50,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 24.4,
        "humidity": 87,
        "rain_prob": 55,
        "condition": "overcast"
      },
      {
        "time": "10:00",
        "temp": 25.5,
        "humidity": 85,
        "rain_prob": 63,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 27.6,
        "humidity": 76,
        "rain_prob": 75,
        "condition": "overcast"
      },
      {
        "time": "12:00",
        "temp": 25.7,
        "humidity": 84,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.6,
        "humidity": 81,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 27.8,
        "humidity": 77,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 27.8,
        "humidity": 75,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 27.3,
        "humidity": 79,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 25.4,
        "humidity": 85,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 23.9,
        "humidity": 92,
        "rain_prob": 88,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 23.3,
        "humidity": 96,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 23.6,
        "humidity": 94,
        "rain_prob": 89,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 23.1,
        "humidity": 95,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.7,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.4,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "thunderstorm"
      }
    ]
  },
  {
    "id": "VN_TH",
    "name": "Thanh Hóa",
    "province": "Thanh Hóa",
    "region": "Miền Trung",
    "type": "Tỉnh",
    "lat": 19.8077,
    "lon": 105.7765,
    "condition": "light_rain",
    "weather_text": "Mưa phùn dày hạt, trời se lạnh",
    "temp": 27.7,
    "feels_like": 31.5,
    "humidity": 77,
    "wind_speed": 15.5,
    "wind_dir": "Đông Bắc",
    "rain_prob": 10,
    "rain_mm": 0.2,
    "uv": 6.3,
    "pressure": 1017,
    "visibility": 13.3,
    "pm25": 10.1,
    "pm10": 11.4,
    "no2": 7.5,
    "co": 0.55,
    "o3": 102.0,
    "so2": 19.9,
    "outdoor_activities": [
      "Đi biển",
      "Đi dạo",
      "Chụp ảnh"
    ],
    "outdoor_score": 83,
    "best_time": "08:00 - 11:00, 15:00 - 18:00",
    "outdoor_advice": "Dạo bờ biển Sầm Sơn và tham quan Thành Nhà Hồ thời tiết tạnh ráo.",
    "station_id": "VN_TH",
    "station_name": "Trạm Thanh Hóa",
    "district": "Thanh Hóa",
    "latitude": 19.8077,
    "longitude": 105.7765,
    "temperature": 27.7,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_TH_01",
        "name": "Trạm Trung tâm TP Thanh Hóa",
        "type": "Đô thị",
        "address": "Đường Trần Phú, P. Điện Biên",
        "lat": 19.812,
        "lon": 105.782,
        "pm25": 10.7,
        "pm10": 16.0,
        "aqi": 19,
        "temp": 27.9,
        "humidity": 75,
        "wind": 15.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TH_02",
        "name": "Trạm Du lịch Biển Sầm Sơn",
        "type": "Ven biển",
        "address": "Đường Hồ Xuân Hương, TP. Sầm Sơn",
        "lat": 19.745,
        "lon": 105.905,
        "pm25": 9.5,
        "pm10": 14.2,
        "aqi": 17,
        "temp": 27.5,
        "humidity": 77,
        "wind": 15.3,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TH_03",
        "name": "Trạm KKT Nghi Sơn",
        "type": "Công nghiệp nặng & Lọc dầu",
        "address": "Khu kinh tế Nghi Sơn, TX. Nghi Sơn",
        "lat": 19.345,
        "lon": 105.785,
        "pm25": 10.1,
        "pm10": 15.1,
        "aqi": 18,
        "temp": 27.7,
        "humidity": 80,
        "wind": 15.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TH",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 22.6,
        "humidity": 97,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 23.2,
        "humidity": 98,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 22.4,
        "humidity": 97,
        "rain_prob": 81,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 22.3,
        "humidity": 98,
        "rain_prob": 60,
        "condition": "sunny"
      },
      {
        "time": "04:00",
        "temp": 22.3,
        "humidity": 99,
        "rain_prob": 45,
        "condition": "sunny"
      },
      {
        "time": "05:00",
        "temp": 22.3,
        "humidity": 98,
        "rain_prob": 42,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 22.2,
        "humidity": 98,
        "rain_prob": 44,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 22.7,
        "humidity": 92,
        "rain_prob": 49,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 24.4,
        "humidity": 86,
        "rain_prob": 54,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 25.3,
        "humidity": 83,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 26.5,
        "humidity": 78,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 27.1,
        "humidity": 78,
        "rain_prob": 79,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 27.8,
        "humidity": 74,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 27.7,
        "humidity": 78,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 27.7,
        "humidity": 77,
        "rain_prob": 99,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 26.7,
        "humidity": 82,
        "rain_prob": 95,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 25.4,
        "humidity": 88,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 25.1,
        "humidity": 93,
        "rain_prob": 89,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 24.4,
        "humidity": 96,
        "rain_prob": 87,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 24.2,
        "humidity": 95,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 23.0,
        "humidity": 97,
        "rain_prob": 88,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 22.9,
        "humidity": 98,
        "rain_prob": 93,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 22.8,
        "humidity": 97,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 22.2,
        "humidity": 97,
        "rain_prob": 98,
        "condition": "thunderstorm"
      }
    ]
  },
  {
    "id": "VN_NA",
    "name": "Nghệ An",
    "province": "Nghệ An",
    "region": "Miền Trung",
    "type": "Tỉnh",
    "lat": 18.6734,
    "lon": 105.6813,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 26.3,
    "feels_like": 30.1,
    "humidity": 82,
    "wind_speed": 11.2,
    "wind_dir": "Bắc",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 6.5,
    "pressure": 1016,
    "visibility": 13.2,
    "pm25": 12.3,
    "pm10": 15.8,
    "no2": 4.5,
    "co": 0.57,
    "o3": 109.0,
    "so2": 10.1,
    "outdoor_activities": [
      "Tham quan",
      "Du lịch"
    ],
    "outdoor_score": 82,
    "best_time": "08:30 - 11:30, 14:30 - 17:00",
    "outdoor_advice": "Về thăm quê Bác Nam Đàn và quảng trường Hồ Chí Minh thời tiết mát dịu.",
    "station_id": "VN_NA",
    "station_name": "Trạm Nghệ An",
    "district": "Nghệ An",
    "latitude": 18.6734,
    "longitude": 105.6813,
    "temperature": 26.3,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_NA_01",
        "name": "Trạm Trung tâm TP Vinh",
        "type": "Đô thị",
        "address": "Đường Lê Mao, P. Lê Mao",
        "lat": 18.675,
        "lon": 105.684,
        "pm25": 11.1,
        "pm10": 16.6,
        "aqi": 20,
        "temp": 25.9,
        "humidity": 83,
        "wind": 10.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_NA",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_NA_02",
        "name": "Trạm Quê Bác - Nam Đàn",
        "type": "Trạm nền văn hóa",
        "address": "Khu di tích Kim Liên, H. Nam Đàn",
        "lat": 18.685,
        "lon": 105.545,
        "pm25": 12.3,
        "pm10": 18.5,
        "aqi": 22,
        "temp": 26.3,
        "humidity": 80,
        "wind": 11.2,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_NA",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_NA_03",
        "name": "Trạm Thị xã Biển Cửa Lò",
        "type": "Ven biển",
        "address": "Đường Bình Minh, TX. Cửa Lò",
        "lat": 18.805,
        "lon": 105.725,
        "pm25": 12.3,
        "pm10": 18.5,
        "aqi": 22,
        "temp": 26.3,
        "humidity": 85,
        "wind": 11.2,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_NA",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.1,
        "humidity": 97,
        "rain_prob": 84,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 24.7,
        "humidity": 98,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 24.3,
        "humidity": 99,
        "rain_prob": 77,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 23.8,
        "humidity": 97,
        "rain_prob": 79,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 24.1,
        "humidity": 96,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 23.7,
        "humidity": 97,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 23.7,
        "humidity": 97,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 23.7,
        "humidity": 96,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 24.4,
        "humidity": 93,
        "rain_prob": 96,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 25.3,
        "humidity": 87,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 26.1,
        "humidity": 84,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 26.3,
        "humidity": 83,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 25.7,
        "humidity": 83,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 26.6,
        "humidity": 81,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 28.0,
        "humidity": 76,
        "rain_prob": 85,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 27.8,
        "humidity": 76,
        "rain_prob": 72,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 27.5,
        "humidity": 80,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 27.3,
        "humidity": 80,
        "rain_prob": 53,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 26.8,
        "humidity": 84,
        "rain_prob": 46,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 26.5,
        "humidity": 84,
        "rain_prob": 45,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 26.3,
        "humidity": 85,
        "rain_prob": 53,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.2,
        "humidity": 91,
        "rain_prob": 68,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 24.3,
        "humidity": 96,
        "rain_prob": 80,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 23.8,
        "humidity": 95,
        "rain_prob": 89,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_HT",
    "name": "Hà Tĩnh",
    "province": "Hà Tĩnh",
    "region": "Miền Trung",
    "type": "Tỉnh",
    "lat": 18.3433,
    "lon": 105.9058,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 28.3,
    "feels_like": 33.0,
    "humidity": 71,
    "wind_speed": 11.3,
    "wind_dir": "Bắc",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 6.7,
    "pressure": 1016,
    "visibility": 13.4,
    "pm25": 9.3,
    "pm10": 12.5,
    "no2": 4.3,
    "co": 0.47,
    "o3": 100.0,
    "so2": 6.7,
    "outdoor_activities": [
      "Tham quan"
    ],
    "outdoor_score": 75,
    "best_time": "09:00 - 12:00",
    "outdoor_advice": "Viếng ngã ba Đồng Lộc và hồ Kẻ Gỗ; nên mang theo dù phòng mưa phùn lất phất.",
    "station_id": "VN_HT",
    "station_name": "Trạm Hà Tĩnh",
    "district": "Hà Tĩnh",
    "latitude": 18.3433,
    "longitude": 105.9058,
    "temperature": 28.3,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_HT_01",
        "name": "Trạm Trung tâm TP Hà Tĩnh",
        "type": "Đô thị",
        "address": "Đường Phan Đình Phùng, P. Bắc Hà",
        "lat": 18.345,
        "lon": 105.908,
        "pm25": 9.9,
        "pm10": 14.9,
        "aqi": 18,
        "temp": 28.5,
        "humidity": 70,
        "wind": 11.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HT_02",
        "name": "Trạm KKT Vũng Áng - Formosa",
        "type": "Công nghiệp nặng",
        "address": "Khu kinh tế Vũng Áng, TX. Kỳ Anh",
        "lat": 18.065,
        "lon": 106.385,
        "pm25": 10.5,
        "pm10": 15.8,
        "aqi": 19,
        "temp": 28.7,
        "humidity": 70,
        "wind": 11.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_HT_03",
        "name": "Trạm Khu Di tích Ngã ba Đồng Lộc",
        "type": "Trạm nền lịch sử",
        "address": "Huyện Can Lộc",
        "lat": 18.425,
        "lon": 105.752,
        "pm25": 8.1,
        "pm10": 12.1,
        "aqi": 15,
        "temp": 27.9,
        "humidity": 71,
        "wind": 10.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_HT",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 23.7,
        "humidity": 96,
        "rain_prob": 56,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 24.2,
        "humidity": 95,
        "rain_prob": 55,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 24.1,
        "humidity": 96,
        "rain_prob": 60,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 24.1,
        "humidity": 97,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 23.4,
        "humidity": 96,
        "rain_prob": 76,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 22.5,
        "humidity": 96,
        "rain_prob": 79,
        "condition": "thunderstorm"
      },
      {
        "time": "06:00",
        "temp": 22.3,
        "humidity": 97,
        "rain_prob": 80,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 22.1,
        "humidity": 96,
        "rain_prob": 82,
        "condition": "thunderstorm"
      },
      {
        "time": "08:00",
        "temp": 22.7,
        "humidity": 96,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 24.7,
        "humidity": 89,
        "rain_prob": 89,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 27.4,
        "humidity": 77,
        "rain_prob": 90,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 28.2,
        "humidity": 72,
        "rain_prob": 89,
        "condition": "partly_cloudy"
      },
      {
        "time": "12:00",
        "temp": 27.0,
        "humidity": 78,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 28.7,
        "humidity": 69,
        "rain_prob": 80,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 28.4,
        "humidity": 70,
        "rain_prob": 70,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 28.2,
        "humidity": 72,
        "rain_prob": 57,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 27.9,
        "humidity": 75,
        "rain_prob": 45,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 27.0,
        "humidity": 81,
        "rain_prob": 33,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 26.2,
        "humidity": 86,
        "rain_prob": 21,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 25.8,
        "humidity": 89,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 25.4,
        "humidity": 91,
        "rain_prob": 13,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 24.8,
        "humidity": 94,
        "rain_prob": 16,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 24.3,
        "humidity": 95,
        "rain_prob": 25,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 23.4,
        "humidity": 96,
        "rain_prob": 44,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_QT",
    "name": "Quảng Trị",
    "province": "Quảng Trị",
    "region": "Miền Trung",
    "type": "Tỉnh",
    "lat": 16.8167,
    "lon": 107.1,
    "condition": "sunny",
    "weather_text": "Trời trong xanh, ít mây, nắng dịu",
    "temp": 28.3,
    "feels_like": 32.4,
    "humidity": 75,
    "wind_speed": 16.0,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.8,
    "pressure": 1014,
    "visibility": 14.6,
    "pm25": 6.1,
    "pm10": 9.5,
    "no2": 0.6,
    "co": 0.34,
    "o3": 83.0,
    "so2": 1.2,
    "outdoor_activities": [
      "Tham quan di tích lịch sử"
    ],
    "outdoor_score": 70,
    "best_time": "10:00 - 14:00",
    "outdoor_advice": "Tham quan Thành cổ Quảng Trị, địa đạo Vịnh Mốc; chú ý đường trơn do mưa rào nhẹ.",
    "station_id": "VN_QT",
    "station_name": "Trạm Quảng Trị",
    "district": "Quảng Trị",
    "latitude": 16.8167,
    "longitude": 107.1,
    "temperature": 28.3,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_QT_01",
        "name": "Trạm TP Đông Hà",
        "type": "Đô thị",
        "address": "Đường Hùng Vương, P. 1",
        "lat": 16.822,
        "lon": 107.098,
        "pm25": 6.1,
        "pm10": 9.1,
        "aqi": 11,
        "temp": 28.3,
        "humidity": 74,
        "wind": 16.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_QT_02",
        "name": "Trạm TX Quảng Trị - Thành Cổ",
        "type": "Văn hóa di tích",
        "address": "Đường Hai Bà Trưng, P. 2",
        "lat": 16.748,
        "lon": 107.185,
        "pm25": 4.9,
        "pm10": 7.4,
        "aqi": 9,
        "temp": 27.9,
        "humidity": 77,
        "wind": 15.6,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_QT_03",
        "name": "Trạm Cửa khẩu Quốc tế Lao Bảo",
        "type": "Giao thông biên giới",
        "address": "Thị trấn Lao Bảo, H. Hướng Hóa",
        "lat": 16.615,
        "lon": 106.592,
        "pm25": 6.1,
        "pm10": 9.1,
        "aqi": 11,
        "temp": 28.3,
        "humidity": 75,
        "wind": 16.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QT",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.5,
        "humidity": 89,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 25.6,
        "humidity": 88,
        "rain_prob": 8,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 25.1,
        "humidity": 88,
        "rain_prob": 19,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 25.0,
        "humidity": 91,
        "rain_prob": 39,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 24.6,
        "humidity": 93,
        "rain_prob": 55,
        "condition": "sunny"
      },
      {
        "time": "05:00",
        "temp": 24.3,
        "humidity": 91,
        "rain_prob": 60,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 23.0,
        "humidity": 99,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "07:00",
        "temp": 24.1,
        "humidity": 94,
        "rain_prob": 63,
        "condition": "light_rain"
      },
      {
        "time": "08:00",
        "temp": 26.1,
        "humidity": 84,
        "rain_prob": 66,
        "condition": "light_rain"
      },
      {
        "time": "09:00",
        "temp": 27.7,
        "humidity": 76,
        "rain_prob": 70,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 28.4,
        "humidity": 73,
        "rain_prob": 75,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 27.8,
        "humidity": 74,
        "rain_prob": 83,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 27.6,
        "humidity": 78,
        "rain_prob": 91,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 28.5,
        "humidity": 73,
        "rain_prob": 98,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 29.1,
        "humidity": 72,
        "rain_prob": 100,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 28.5,
        "humidity": 74,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 27.9,
        "humidity": 77,
        "rain_prob": 100,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 27.4,
        "humidity": 78,
        "rain_prob": 94,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.7,
        "humidity": 82,
        "rain_prob": 85,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 26.4,
        "humidity": 84,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 26.4,
        "humidity": 84,
        "rain_prob": 74,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 26.4,
        "humidity": 83,
        "rain_prob": 71,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 26.1,
        "humidity": 84,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 25.6,
        "humidity": 86,
        "rain_prob": 69,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_QNG",
    "name": "Quảng Ngãi",
    "province": "Quảng Ngãi",
    "region": "Miền Trung",
    "type": "Tỉnh",
    "lat": 15.1205,
    "lon": 108.7923,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 30.5,
    "feels_like": 35.2,
    "humidity": 63,
    "wind_speed": 12.1,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 6.9,
    "pressure": 1014,
    "visibility": 14.3,
    "pm25": 9.9,
    "pm10": 13.8,
    "no2": 1.2,
    "co": 0.33,
    "o3": 100.0,
    "so2": 2.9,
    "outdoor_activities": [
      "Đi biển",
      "Du lịch đảo",
      "Chụp ảnh"
    ],
    "outdoor_score": 93,
    "best_time": "07:00 - 10:30, 15:00 - 18:00",
    "outdoor_advice": "Biển đảo Lý Sơn sóng êm nước trong vắt, thời tiết tuyệt hảo để lặn ngắm san hô.",
    "station_id": "VN_QNG",
    "station_name": "Trạm Quảng Ngãi",
    "district": "Quảng Ngãi",
    "latitude": 15.1205,
    "longitude": 108.7923,
    "temperature": 30.5,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_QNG_01",
        "name": "Trạm Trung tâm TP Quảng Ngãi",
        "type": "Đô thị",
        "address": "Đường Quang Trung, P. Lê Hồng Phong",
        "lat": 15.122,
        "lon": 108.795,
        "pm25": 8.7,
        "pm10": 13.0,
        "aqi": 16,
        "temp": 30.1,
        "humidity": 62,
        "wind": 11.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QNG",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_QNG_02",
        "name": "Trạm KKT Dung Quất - Lọc dầu",
        "type": "Công nghiệp nặng & Lọc dầu",
        "address": "Khu kinh tế Dung Quất, H. Bình Sơn",
        "lat": 15.412,
        "lon": 108.785,
        "pm25": 10.5,
        "pm10": 15.8,
        "aqi": 19,
        "temp": 30.7,
        "humidity": 62,
        "wind": 12.3,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QNG",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_QNG_03",
        "name": "Trạm Đảo Sinh thái Lý Sơn",
        "type": "Sinh thái biển đảo",
        "address": "Huyện đảo Lý Sơn",
        "lat": 15.378,
        "lon": 109.125,
        "pm25": 11.1,
        "pm10": 16.6,
        "aqi": 20,
        "temp": 30.9,
        "humidity": 61,
        "wind": 12.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_QNG",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.4,
        "humidity": 97,
        "rain_prob": 39,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 24.6,
        "humidity": 98,
        "rain_prob": 29,
        "condition": "sunny"
      },
      {
        "time": "02:00",
        "temp": 24.4,
        "humidity": 99,
        "rain_prob": 38,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 24.1,
        "humidity": 100,
        "rain_prob": 54,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 23.9,
        "humidity": 99,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 23.7,
        "humidity": 99,
        "rain_prob": 48,
        "condition": "light_rain"
      },
      {
        "time": "06:00",
        "temp": 23.6,
        "humidity": 99,
        "rain_prob": 26,
        "condition": "partly_cloudy"
      },
      {
        "time": "07:00",
        "temp": 24.9,
        "humidity": 96,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 26.9,
        "humidity": 82,
        "rain_prob": 22,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.7,
        "humidity": 71,
        "rain_prob": 39,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 29.8,
        "humidity": 67,
        "rain_prob": 53,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 30.3,
        "humidity": 64,
        "rain_prob": 59,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 30.6,
        "humidity": 62,
        "rain_prob": 61,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 30.4,
        "humidity": 63,
        "rain_prob": 61,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 29.9,
        "humidity": 66,
        "rain_prob": 56,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 29.2,
        "humidity": 70,
        "rain_prob": 49,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 28.5,
        "humidity": 74,
        "rain_prob": 43,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 27.5,
        "humidity": 79,
        "rain_prob": 40,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 26.4,
        "humidity": 84,
        "rain_prob": 38,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 26.0,
        "humidity": 84,
        "rain_prob": 41,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 25.8,
        "humidity": 85,
        "rain_prob": 51,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.6,
        "humidity": 85,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 24.6,
        "humidity": 93,
        "rain_prob": 76,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 23.5,
        "humidity": 98,
        "rain_prob": 79,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_GL",
    "name": "Gia Lai",
    "province": "Gia Lai",
    "region": "Tây Nguyên",
    "type": "Tỉnh",
    "lat": 13.9833,
    "lon": 108.0,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 27.7,
    "feels_like": 28.8,
    "humidity": 56,
    "wind_speed": 21.6,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.2,
    "pressure": 932,
    "visibility": 14.7,
    "pm25": 4.3,
    "pm10": 5.7,
    "no2": 0.4,
    "co": 0.31,
    "o3": 84.0,
    "so2": 1.5,
    "outdoor_activities": [
      "Picnic",
      "Chụp ảnh",
      "Đi dạo",
      "Chạy bộ"
    ],
    "outdoor_score": 97,
    "best_time": "07:00 - 11:00, 14:30 - 17:30",
    "outdoor_advice": "Không khí sạch đạt chuẩn WHO! Hồ Tơ Nưng (Biển Hồ) phẳng lặng như gương, lý tưởng picnic và check-in hàng thông trăm tuổi.",
    "station_id": "VN_GL",
    "station_name": "Trạm Gia Lai",
    "district": "Gia Lai",
    "latitude": 13.9833,
    "longitude": 108.0,
    "temperature": 27.7,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_GL_01",
        "name": "Trạm Pleiku - Quảng trường Đại Đoàn Kết",
        "type": "Đô thị cao nguyên",
        "address": "Đường Trần Hưng Đạo, P. Tây Sơn",
        "lat": 13.985,
        "lon": 108.005,
        "pm25": 4.3,
        "pm10": 6.4,
        "aqi": 8,
        "temp": 27.7,
        "humidity": 53,
        "wind": 21.6,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_GL",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_GL_02",
        "name": "Trạm Thắng cảnh Biển Hồ (Tơ Nưng)",
        "type": "Trạm nền sinh thái hồ",
        "address": "Xã Biển Hồ, TP. Pleiku",
        "lat": 14.048,
        "lon": 108.002,
        "pm25": 3.1,
        "pm10": 4.7,
        "aqi": 6,
        "temp": 27.3,
        "humidity": 57,
        "wind": 21.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_GL",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_GL_03",
        "name": "Trạm Rừng Quốc gia Kon Ka Kinh",
        "type": "Trạm nền rừng đặc dụng",
        "address": "Huyện Mang Yang",
        "lat": 14.315,
        "lon": 108.385,
        "pm25": 3.7,
        "pm10": 5.6,
        "aqi": 7,
        "temp": 27.5,
        "humidity": 57,
        "wind": 21.4,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_GL",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 20.6,
        "humidity": 91,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 20.6,
        "humidity": 91,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 20.4,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "03:00",
        "temp": 20.2,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 20.2,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 20.2,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 20.2,
        "humidity": 91,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "07:00",
        "temp": 21.7,
        "humidity": 83,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 23.3,
        "humidity": 78,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 25.1,
        "humidity": 70,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 26.2,
        "humidity": 65,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 27.1,
        "humidity": 61,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 27.4,
        "humidity": 57,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 27.8,
        "humidity": 55,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 27.5,
        "humidity": 56,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 26.9,
        "humidity": 58,
        "rain_prob": 5,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 25.8,
        "humidity": 63,
        "rain_prob": 6,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 24.0,
        "humidity": 71,
        "rain_prob": 5,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 22.8,
        "humidity": 76,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 22.1,
        "humidity": 79,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 21.5,
        "humidity": 81,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 21.1,
        "humidity": 82,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 21.1,
        "humidity": 83,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 21.0,
        "humidity": 86,
        "rain_prob": 0,
        "condition": "sunny"
      }
    ]
  },
  {
    "id": "VN_KH",
    "name": "Khánh Hòa",
    "province": "Khánh Hòa",
    "region": "Miền Trung",
    "type": "Tỉnh",
    "lat": 12.2388,
    "lon": 109.1967,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 30.1,
    "feels_like": 32.9,
    "humidity": 61,
    "wind_speed": 21.6,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.3,
    "pressure": 1013,
    "visibility": 14.4,
    "pm25": 9.3,
    "pm10": 13.6,
    "no2": 0.6,
    "co": 0.27,
    "o3": 97.0,
    "so2": 1.6,
    "outdoor_activities": [
      "Đi biển",
      "Chạy bộ",
      "Đạp xe",
      "Du lịch"
    ],
    "outdoor_score": 98,
    "best_time": "06:00 - 09:30, 15:30 - 18:30",
    "outdoor_advice": "Thiên đường nghỉ dưỡng biển! Nắng đẹp không khí trong lành, rất thích hợp tắm biển Trần Phú và tour 4 đảo.",
    "station_id": "VN_KH",
    "station_name": "Trạm Khánh Hòa",
    "district": "Khánh Hòa",
    "latitude": 12.2388,
    "longitude": 109.1967,
    "temperature": 30.1,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_KH_01",
        "name": "Trạm Bờ biển Trần Phú - Nha Trang",
        "type": "Đô thị du lịch",
        "address": "Đường Trần Phú, TP. Nha Trang",
        "lat": 12.242,
        "lon": 109.198,
        "pm25": 10.5,
        "pm10": 15.8,
        "aqi": 19,
        "temp": 30.5,
        "humidity": 58,
        "wind": 22.0,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_KH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_KH_02",
        "name": "Trạm Bán đảo Cam Ranh & Sân bay",
        "type": "Giao thông ven vịnh",
        "address": "TP. Cam Ranh",
        "lat": 11.995,
        "lon": 109.135,
        "pm25": 9.9,
        "pm10": 14.9,
        "aqi": 18,
        "temp": 30.3,
        "humidity": 58,
        "wind": 21.8,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_KH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_KH_03",
        "name": "Trạm Đảo Hòn Tre - Vinpearl",
        "type": "Sinh thái đảo",
        "address": "Vịnh Nha Trang",
        "lat": 12.215,
        "lon": 109.255,
        "pm25": 8.1,
        "pm10": 12.1,
        "aqi": 15,
        "temp": 29.7,
        "humidity": 61,
        "wind": 21.2,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_KH",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.7,
        "humidity": 87,
        "rain_prob": 23,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 23.6,
        "humidity": 96,
        "rain_prob": 22,
        "condition": "light_rain"
      },
      {
        "time": "02:00",
        "temp": 23.4,
        "humidity": 97,
        "rain_prob": 46,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 23.4,
        "humidity": 97,
        "rain_prob": 82,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 23.4,
        "humidity": 96,
        "rain_prob": 100,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 23.5,
        "humidity": 94,
        "rain_prob": 81,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 23.8,
        "humidity": 92,
        "rain_prob": 45,
        "condition": "overcast"
      },
      {
        "time": "07:00",
        "temp": 25.1,
        "humidity": 84,
        "rain_prob": 22,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 27.1,
        "humidity": 75,
        "rain_prob": 29,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.6,
        "humidity": 68,
        "rain_prob": 49,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 29.3,
        "humidity": 65,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 29.5,
        "humidity": 65,
        "rain_prob": 71,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 30.0,
        "humidity": 62,
        "rain_prob": 74,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 30.1,
        "humidity": 61,
        "rain_prob": 76,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 29.5,
        "humidity": 66,
        "rain_prob": 78,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 29.0,
        "humidity": 71,
        "rain_prob": 79,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 28.6,
        "humidity": 71,
        "rain_prob": 80,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 25.8,
        "humidity": 89,
        "rain_prob": 79,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 24.4,
        "humidity": 94,
        "rain_prob": 77,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 24.6,
        "humidity": 96,
        "rain_prob": 78,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 24.6,
        "humidity": 95,
        "rain_prob": 84,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 24.4,
        "humidity": 94,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "22:00",
        "temp": 23.8,
        "humidity": 94,
        "rain_prob": 98,
        "condition": "light_rain"
      },
      {
        "time": "23:00",
        "temp": 24.0,
        "humidity": 94,
        "rain_prob": 99,
        "condition": "light_rain"
      }
    ]
  },
  {
    "id": "VN_DLAK",
    "name": "Đắk Lắk",
    "province": "Đắk Lắk",
    "region": "Tây Nguyên",
    "type": "Tỉnh",
    "lat": 12.6667,
    "lon": 108.05,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 29.8,
    "feels_like": 31.7,
    "humidity": 55,
    "wind_speed": 21.5,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.3,
    "pressure": 961,
    "visibility": 14.6,
    "pm25": 5.5,
    "pm10": 7.4,
    "no2": 0.8,
    "co": 0.29,
    "o3": 91.0,
    "so2": 2.0,
    "outdoor_activities": [
      "Du lịch",
      "Picnic",
      "Tham quan"
    ],
    "outdoor_score": 92,
    "best_time": "07:30 - 11:00, 14:30 - 17:30",
    "outdoor_advice": "Thời tiết đẹp để thưởng thức cà phê đường Phan Đình Giót, tham quan bảo tàng Thế giới Cà phê, hồ Lắk.",
    "station_id": "VN_DLAK",
    "station_name": "Trạm Đắk Lắk",
    "district": "Đắk Lắk",
    "latitude": 12.6667,
    "longitude": 108.05,
    "temperature": 29.8,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_DLAK_01",
        "name": "Trạm Buôn Ma Thuột - Thủ phủ Cà phê",
        "type": "Đô thị",
        "address": "Đường Lê Duẩn, P. Tân Thành",
        "lat": 12.671,
        "lon": 108.048,
        "pm25": 6.1,
        "pm10": 9.1,
        "aqi": 11,
        "temp": 30.0,
        "humidity": 58,
        "wind": 21.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DLAK",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DLAK_02",
        "name": "Trạm Sinh thái Hồ Lắk",
        "type": "Sinh thái hồ nước",
        "address": "Thị trấn Liên Sơn, H. Lắk",
        "lat": 12.415,
        "lon": 108.185,
        "pm25": 6.7,
        "pm10": 10.1,
        "aqi": 12,
        "temp": 30.2,
        "humidity": 55,
        "wind": 21.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DLAK",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DLAK_03",
        "name": "Trạm KCN Hòa Phú",
        "type": "Công nghiệp",
        "address": "Xã Hòa Phú, TP. Buôn Ma Thuột",
        "lat": 12.585,
        "lon": 107.955,
        "pm25": 4.9,
        "pm10": 7.4,
        "aqi": 9,
        "temp": 29.6,
        "humidity": 57,
        "wind": 21.3,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DLAK",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 23.3,
        "humidity": 87,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 23.1,
        "humidity": 87,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "02:00",
        "temp": 22.7,
        "humidity": 88,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "03:00",
        "temp": 22.6,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 22.7,
        "humidity": 87,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 22.8,
        "humidity": 85,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "06:00",
        "temp": 22.6,
        "humidity": 88,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "07:00",
        "temp": 23.8,
        "humidity": 83,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 25.3,
        "humidity": 75,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 26.8,
        "humidity": 68,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 28.0,
        "humidity": 62,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 28.8,
        "humidity": 58,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 29.6,
        "humidity": 55,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 29.8,
        "humidity": 55,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 29.4,
        "humidity": 56,
        "rain_prob": 1,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 28.7,
        "humidity": 58,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 27.6,
        "humidity": 60,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 26.2,
        "humidity": 67,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 25.0,
        "humidity": 73,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 24.3,
        "humidity": 79,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 23.9,
        "humidity": 84,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "21:00",
        "temp": 23.8,
        "humidity": 85,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "22:00",
        "temp": 23.8,
        "humidity": 86,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "23:00",
        "temp": 23.7,
        "humidity": 86,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      }
    ]
  },
  {
    "id": "VN_LD",
    "name": "Lâm Đồng",
    "province": "Lâm Đồng",
    "region": "Tây Nguyên",
    "type": "Tỉnh",
    "lat": 11.9404,
    "lon": 108.4583,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 24.0,
    "feels_like": 24.1,
    "humidity": 61,
    "wind_speed": 21.5,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.7,
    "pressure": 856,
    "visibility": 14.7,
    "pm25": 4.2,
    "pm10": 5.7,
    "no2": 0.5,
    "co": 0.27,
    "o3": 84.0,
    "so2": 1.3,
    "outdoor_activities": [
      "Đi dạo",
      "Chụp ảnh",
      "Đạp xe",
      "Picnic",
      "Chạy bộ",
      "Du lịch"
    ],
    "outdoor_score": 99,
    "best_time": "07:00 - 11:30, 14:00 - 18:00",
    "outdoor_advice": "Điểm đến hoàn hảo nhất hôm nay! Chỉ số AQI sạch nhất Việt Nam (PM2.5 chỉ 8.5 µg/m³), hoa dã quỳ khoe sắc, cần áo len mỏng.",
    "station_id": "VN_LD",
    "station_name": "Trạm Lâm Đồng",
    "district": "Lâm Đồng",
    "latitude": 11.9404,
    "longitude": 108.4583,
    "temperature": 24.0,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_LD_01",
        "name": "Trạm Hồ Xuân Hương - Đà Lạt",
        "type": "Đô thị ngàn hoa",
        "address": "Đường Trần Quốc Toản, P. 1, TP. Đà Lạt",
        "lat": 11.944,
        "lon": 108.448,
        "pm25": 5.4,
        "pm10": 8.1,
        "aqi": 10,
        "temp": 24.4,
        "humidity": 62,
        "wind": 21.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LD",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_LD_02",
        "name": "Trạm Đèo Prenn - Rừng thông",
        "type": "Trạm nền sinh thái rừng thông",
        "address": "Đèo Prenn, TP. Đà Lạt",
        "lat": 11.895,
        "lon": 108.442,
        "pm25": 4.2,
        "pm10": 6.3,
        "aqi": 8,
        "temp": 24.0,
        "humidity": 63,
        "wind": 21.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LD",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_LD_03",
        "name": "Trạm TP Bảo Lộc - Vùng Đồi Chè",
        "type": "Đô thị cao nguyên trà",
        "address": "Đường Lê Hồng Phong, TP. Bảo Lộc",
        "lat": 11.545,
        "lon": 107.805,
        "pm25": 4.8,
        "pm10": 7.2,
        "aqi": 9,
        "temp": 24.2,
        "humidity": 58,
        "wind": 21.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_LD",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 15.7,
        "humidity": 97,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 15.6,
        "humidity": 98,
        "rain_prob": 0,
        "condition": "foggy"
      },
      {
        "time": "02:00",
        "temp": 15.4,
        "humidity": 97,
        "rain_prob": 4,
        "condition": "partly_cloudy"
      },
      {
        "time": "03:00",
        "temp": 15.2,
        "humidity": 95,
        "rain_prob": 9,
        "condition": "partly_cloudy"
      },
      {
        "time": "04:00",
        "temp": 15.4,
        "humidity": 95,
        "rain_prob": 12,
        "condition": "sunny"
      },
      {
        "time": "05:00",
        "temp": 15.3,
        "humidity": 96,
        "rain_prob": 9,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 15.5,
        "humidity": 96,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 17.7,
        "humidity": 91,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 19.7,
        "humidity": 82,
        "rain_prob": 0,
        "condition": "overcast"
      },
      {
        "time": "09:00",
        "temp": 21.2,
        "humidity": 73,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "10:00",
        "temp": 22.6,
        "humidity": 66,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 23.3,
        "humidity": 63,
        "rain_prob": 3,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 24.2,
        "humidity": 59,
        "rain_prob": 8,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 23.9,
        "humidity": 61,
        "rain_prob": 12,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 23.3,
        "humidity": 62,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 22.4,
        "humidity": 63,
        "rain_prob": 15,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 21.0,
        "humidity": 70,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "17:00",
        "temp": 19.1,
        "humidity": 80,
        "rain_prob": 10,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 18.0,
        "humidity": 86,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 17.5,
        "humidity": 88,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 17.5,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 17.8,
        "humidity": 89,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 17.9,
        "humidity": 88,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 17.7,
        "humidity": 92,
        "rain_prob": 1,
        "condition": "overcast"
      }
    ]
  },
  {
    "id": "VN_DNAI",
    "name": "Đồng Nai",
    "province": "Đồng Nai",
    "region": "Miền Nam",
    "type": "Tỉnh",
    "lat": 10.9574,
    "lon": 106.8427,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 31.9,
    "feels_like": 38.8,
    "humidity": 63,
    "wind_speed": 6.3,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.5,
    "pressure": 1010,
    "visibility": 13.9,
    "pm25": 16.8,
    "pm10": 18.3,
    "no2": 7.8,
    "co": 0.45,
    "o3": 159.0,
    "so2": 20.3,
    "outdoor_activities": [
      "Dã ngoại",
      "Tham quan sinh thái"
    ],
    "outdoor_score": 78,
    "best_time": "07:00 - 09:30, 16:00 - 18:30",
    "outdoor_advice": "Thích hợp dã ngoại rừng Nam Cát Tiên hoặc khu du lịch Bửu Long vào buổi sáng sớm.",
    "station_id": "VN_DNAI",
    "station_name": "Trạm Đồng Nai",
    "district": "Đồng Nai",
    "latitude": 10.9574,
    "longitude": 106.8427,
    "temperature": 31.9,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_DNAI_01",
        "name": "Trạm TP Biên Hòa - Trung tâm",
        "type": "Đô thị",
        "address": "Đường 30/4, P. Thanh Bình",
        "lat": 10.959,
        "lon": 106.839,
        "pm25": 15.6,
        "pm10": 23.4,
        "aqi": 28,
        "temp": 31.5,
        "humidity": 66,
        "wind": 5.9,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DNAI",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DNAI_02",
        "name": "Trạm KCN Biên Hòa 2 & Amata",
        "type": "Công nghiệp",
        "address": "KCN Biên Hòa 2, TP. Biên Hòa",
        "lat": 10.925,
        "lon": 106.885,
        "pm25": 16.8,
        "pm10": 25.2,
        "aqi": 30,
        "temp": 31.9,
        "humidity": 66,
        "wind": 6.3,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DNAI",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DNAI_03",
        "name": "Trạm Vườn Quốc gia Cát Tiên",
        "type": "Trạm nền rừng nhiệt đới",
        "address": "Huyện Tân Phú",
        "lat": 11.425,
        "lon": 107.415,
        "pm25": 16.2,
        "pm10": 24.3,
        "aqi": 29,
        "temp": 31.7,
        "humidity": 66,
        "wind": 6.1,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DNAI",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.0,
        "humidity": 98,
        "rain_prob": 50,
        "condition": "partly_cloudy"
      },
      {
        "time": "01:00",
        "temp": 25.4,
        "humidity": 96,
        "rain_prob": 25,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 24.9,
        "humidity": 99,
        "rain_prob": 14,
        "condition": "overcast"
      },
      {
        "time": "03:00",
        "temp": 24.6,
        "humidity": 96,
        "rain_prob": 8,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 24.1,
        "humidity": 97,
        "rain_prob": 4,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 24.0,
        "humidity": 97,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 24.0,
        "humidity": 98,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 25.1,
        "humidity": 93,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 26.6,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.2,
        "humidity": 82,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 29.7,
        "humidity": 74,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 30.8,
        "humidity": 67,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 31.5,
        "humidity": 64,
        "rain_prob": 0,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 32.0,
        "humidity": 63,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 32.3,
        "humidity": 62,
        "rain_prob": 23,
        "condition": "partly_cloudy"
      },
      {
        "time": "15:00",
        "temp": 32.1,
        "humidity": 62,
        "rain_prob": 52,
        "condition": "overcast"
      },
      {
        "time": "16:00",
        "temp": 26.3,
        "humidity": 93,
        "rain_prob": 71,
        "condition": "thunderstorm"
      },
      {
        "time": "17:00",
        "temp": 26.4,
        "humidity": 92,
        "rain_prob": 73,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.1,
        "humidity": 95,
        "rain_prob": 64,
        "condition": "partly_cloudy"
      },
      {
        "time": "19:00",
        "temp": 26.1,
        "humidity": 96,
        "rain_prob": 53,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 26.0,
        "humidity": 97,
        "rain_prob": 38,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.9,
        "humidity": 97,
        "rain_prob": 20,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 25.6,
        "humidity": 98,
        "rain_prob": 6,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 25.4,
        "humidity": 99,
        "rain_prob": 1,
        "condition": "sunny"
      }
    ]
  },
  {
    "id": "VN_TNINH",
    "name": "Tây Ninh",
    "province": "Tây Ninh",
    "region": "Miền Nam",
    "type": "Tỉnh",
    "lat": 11.31,
    "lon": 106.0983,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 32.0,
    "feels_like": 38.2,
    "humidity": 60,
    "wind_speed": 7.7,
    "wind_dir": "Đông Bắc",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.5,
    "pressure": 1009,
    "visibility": 14.4,
    "pm25": 8.4,
    "pm10": 10.3,
    "no2": 1.1,
    "co": 0.4,
    "o3": 111.0,
    "so2": 3.1,
    "outdoor_activities": [
      "Leo núi",
      "Du lịch tâm linh",
      "Chụp ảnh"
    ],
    "outdoor_score": 89,
    "best_time": "06:30 - 10:00, 15:30 - 18:30",
    "outdoor_advice": "Trời trong nắng đẹp, rất lý tưởng săn mây cáp treo đỉnh núi Bà Đen và viếng Tòa Thánh Tây Ninh.",
    "station_id": "VN_TNINH",
    "station_name": "Trạm Tây Ninh",
    "district": "Tây Ninh",
    "latitude": 11.31,
    "longitude": 106.0983,
    "temperature": 32.0,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_TNINH_01",
        "name": "Trạm TP Tây Ninh - Trung tâm Đô thị",
        "type": "Đô thị",
        "address": "Đường 30/4, P. 3, TP. Tây Ninh",
        "lat": 11.312,
        "lon": 106.099,
        "pm25": 9.6,
        "pm10": 14.4,
        "aqi": 17,
        "temp": 32.4,
        "humidity": 57,
        "wind": 8.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TNINH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TNINH_02",
        "name": "Trạm Đỉnh Núi Bà Đen - Khí tượng Cao nguyên",
        "type": "Trạm nền khí hậu núi cao",
        "address": "Khu du lịch Quốc gia Núi Bà Đen",
        "lat": 11.385,
        "lon": 106.168,
        "pm25": 8.4,
        "pm10": 12.6,
        "aqi": 15,
        "temp": 32.0,
        "humidity": 61,
        "wind": 7.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TNINH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TNINH_03",
        "name": "Trạm KCN Trảng Bàng - Cửa khẩu Mộc Bài",
        "type": "Công nghiệp & Giao thông",
        "address": "KCN Trảng Bàng, TX. Trảng Bàng",
        "lat": 11.035,
        "lon": 106.355,
        "pm25": 9.6,
        "pm10": 14.4,
        "aqi": 17,
        "temp": 32.4,
        "humidity": 62,
        "wind": 8.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TNINH",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_TNINH_04",
        "name": "Trạm Tòa Thánh Tây Ninh - Tâm linh",
        "type": "Văn hóa du lịch",
        "address": "Phường Hiệp Ninh, TP. Tây Ninh",
        "lat": 11.305,
        "lon": 106.135,
        "pm25": 9.6,
        "pm10": 14.4,
        "aqi": 17,
        "temp": 32.4,
        "humidity": 62,
        "wind": 8.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_TNINH",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.2,
        "humidity": 99,
        "rain_prob": 66,
        "condition": "light_rain"
      },
      {
        "time": "01:00",
        "temp": 24.8,
        "humidity": 98,
        "rain_prob": 51,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 24.5,
        "humidity": 100,
        "rain_prob": 54,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 24.2,
        "humidity": 99,
        "rain_prob": 65,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 24.0,
        "humidity": 99,
        "rain_prob": 67,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 23.8,
        "humidity": 97,
        "rain_prob": 52,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 23.7,
        "humidity": 97,
        "rain_prob": 30,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 24.7,
        "humidity": 94,
        "rain_prob": 12,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 26.5,
        "humidity": 86,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.1,
        "humidity": 80,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 29.6,
        "humidity": 73,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 30.7,
        "humidity": 67,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 31.5,
        "humidity": 63,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 32.1,
        "humidity": 59,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "14:00",
        "temp": 32.0,
        "humidity": 60,
        "rain_prob": 9,
        "condition": "sunny"
      },
      {
        "time": "15:00",
        "temp": 31.9,
        "humidity": 61,
        "rain_prob": 21,
        "condition": "sunny"
      },
      {
        "time": "16:00",
        "temp": 30.6,
        "humidity": 69,
        "rain_prob": 33,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 27.1,
        "humidity": 81,
        "rain_prob": 44,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.0,
        "humidity": 93,
        "rain_prob": 53,
        "condition": "light_rain"
      },
      {
        "time": "19:00",
        "temp": 25.7,
        "humidity": 96,
        "rain_prob": 57,
        "condition": "light_rain"
      },
      {
        "time": "20:00",
        "temp": 25.7,
        "humidity": 97,
        "rain_prob": 51,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.5,
        "humidity": 97,
        "rain_prob": 38,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 25.0,
        "humidity": 99,
        "rain_prob": 27,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 24.8,
        "humidity": 100,
        "rain_prob": 18,
        "condition": "foggy"
      }
    ]
  },
  {
    "id": "VN_DT",
    "name": "Đồng Tháp",
    "province": "Đồng Tháp",
    "region": "Miền Nam",
    "type": "Tỉnh",
    "lat": 10.4577,
    "lon": 105.6322,
    "condition": "sunny",
    "weather_text": "Trời nắng ráo, quang đãng, không mây",
    "temp": 32.1,
    "feels_like": 37.1,
    "humidity": 59,
    "wind_speed": 13.3,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.7,
    "pressure": 1010,
    "visibility": 14.2,
    "pm25": 12.4,
    "pm10": 15.1,
    "no2": 2.0,
    "co": 0.44,
    "o3": 140.0,
    "so2": 8.4,
    "outdoor_activities": [
      "Du lịch sinh thái",
      "Chụp ảnh"
    ],
    "outdoor_score": 90,
    "best_time": "07:00 - 10:30, 15:30 - 18:00",
    "outdoor_advice": "Thời tiết đẹp, thích hợp chèo xuồng ngắm chim tại Vườn quốc gia Tràm Chim, làng hoa Sa Đéc.",
    "station_id": "VN_DT",
    "station_name": "Trạm Đồng Tháp",
    "district": "Đồng Tháp",
    "latitude": 10.4577,
    "longitude": 105.6322,
    "temperature": 32.1,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_DT_01",
        "name": "Trạm TP Cao Lãnh - Trung tâm",
        "type": "Đô thị",
        "address": "Đường Lý Thường Kiệt, P. 1",
        "lat": 10.459,
        "lon": 105.635,
        "pm25": 11.2,
        "pm10": 16.8,
        "aqi": 20,
        "temp": 31.7,
        "humidity": 57,
        "wind": 12.9,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DT_02",
        "name": "Trạm Làng Hoa Sa Đéc",
        "type": "Nông nghiệp hoa kiểng",
        "address": "Xã Tân Quy Đông, TP. Sa Đéc",
        "lat": 10.315,
        "lon": 105.755,
        "pm25": 11.8,
        "pm10": 17.7,
        "aqi": 21,
        "temp": 31.9,
        "humidity": 62,
        "wind": 13.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DT",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_DT_03",
        "name": "Trạm Vườn Quốc gia Tràm Chim",
        "type": "Trạm nền ngập nước",
        "address": "Thị trấn Tràm Chim, H. Tam Nông",
        "lat": 10.715,
        "lon": 105.515,
        "pm25": 13.6,
        "pm10": 20.4,
        "aqi": 24,
        "temp": 32.5,
        "humidity": 58,
        "wind": 13.7,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_DT",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.6,
        "humidity": 97,
        "rain_prob": 20,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 25.9,
        "humidity": 95,
        "rain_prob": 14,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 25.3,
        "humidity": 93,
        "rain_prob": 14,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 25.3,
        "humidity": 94,
        "rain_prob": 16,
        "condition": "partly_cloudy"
      },
      {
        "time": "04:00",
        "temp": 24.9,
        "humidity": 97,
        "rain_prob": 16,
        "condition": "partly_cloudy"
      },
      {
        "time": "05:00",
        "temp": 24.8,
        "humidity": 97,
        "rain_prob": 12,
        "condition": "partly_cloudy"
      },
      {
        "time": "06:00",
        "temp": 24.7,
        "humidity": 97,
        "rain_prob": 6,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 25.7,
        "humidity": 92,
        "rain_prob": 2,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 27.2,
        "humidity": 85,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.6,
        "humidity": 76,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 30.0,
        "humidity": 69,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 31.2,
        "humidity": 62,
        "rain_prob": 17,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 31.8,
        "humidity": 60,
        "rain_prob": 34,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 32.0,
        "humidity": 60,
        "rain_prob": 51,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 31.0,
        "humidity": 64,
        "rain_prob": 66,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 30.4,
        "humidity": 69,
        "rain_prob": 81,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 27.2,
        "humidity": 87,
        "rain_prob": 88,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 27.0,
        "humidity": 89,
        "rain_prob": 84,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.4,
        "humidity": 93,
        "rain_prob": 74,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 25.9,
        "humidity": 95,
        "rain_prob": 61,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 25.7,
        "humidity": 96,
        "rain_prob": 45,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.8,
        "humidity": 94,
        "rain_prob": 28,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 25.8,
        "humidity": 94,
        "rain_prob": 14,
        "condition": "sunny"
      },
      {
        "time": "23:00",
        "temp": 25.7,
        "humidity": 95,
        "rain_prob": 8,
        "condition": "partly_cloudy"
      }
    ]
  },
  {
    "id": "VN_VL",
    "name": "Vĩnh Long",
    "province": "Vĩnh Long",
    "region": "Miền Nam",
    "type": "Tỉnh",
    "lat": 10.2537,
    "lon": 105.9722,
    "condition": "light_rain",
    "weather_text": "Mưa phùn nhẹ lất phất, se lạnh",
    "temp": 31.4,
    "feels_like": 35.8,
    "humidity": 62,
    "wind_speed": 16.7,
    "wind_dir": "Đông",
    "rain_prob": 10,
    "rain_mm": 0.1,
    "uv": 7.7,
    "pressure": 1011,
    "visibility": 13.0,
    "pm25": 15.2,
    "pm10": 17.7,
    "no2": 2.7,
    "co": 0.58,
    "o3": 162.0,
    "so2": 12.4,
    "outdoor_activities": [
      "Du lịch miệt vườn",
      "Thưởng thức ẩm thực"
    ],
    "outdoor_score": 87,
    "best_time": "08:00 - 11:00, 15:00 - 18:00",
    "outdoor_advice": "Khám phá cù lao An Bình thưởng thức trái cây miệt vườn, thời tiết thoáng đãng.",
    "station_id": "VN_VL",
    "station_name": "Trạm Vĩnh Long",
    "district": "Vĩnh Long",
    "latitude": 10.2537,
    "longitude": 105.9722,
    "temperature": 31.4,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_VL_01",
        "name": "Trạm Trung tâm TP Vĩnh Long",
        "type": "Đô thị",
        "address": "Đường Trưng Nữ Vương, P. 1",
        "lat": 10.255,
        "lon": 105.975,
        "pm25": 14.6,
        "pm10": 21.9,
        "aqi": 26,
        "temp": 31.2,
        "humidity": 62,
        "wind": 16.5,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_VL",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_VL_02",
        "name": "Trạm Cù lao An Bình - Miệt vườn",
        "type": "Sinh thái sông nước",
        "address": "Huyện Long Hồ",
        "lat": 10.285,
        "lon": 105.985,
        "pm25": 15.8,
        "pm10": 23.7,
        "aqi": 28,
        "temp": 31.6,
        "humidity": 65,
        "wind": 16.9,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_VL",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_VL_03",
        "name": "Trạm KCN Hòa Phú",
        "type": "Công nghiệp",
        "address": "Xã Hòa Phú, H. Long Hồ",
        "lat": 10.185,
        "lon": 105.955,
        "pm25": 15.2,
        "pm10": 22.8,
        "aqi": 27,
        "temp": 31.4,
        "humidity": 59,
        "wind": 16.7,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_VL",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 24.9,
        "humidity": 89,
        "rain_prob": 26,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 25.3,
        "humidity": 93,
        "rain_prob": 24,
        "condition": "overcast"
      },
      {
        "time": "02:00",
        "temp": 24.8,
        "humidity": 94,
        "rain_prob": 22,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 24.7,
        "humidity": 94,
        "rain_prob": 19,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 24.7,
        "humidity": 94,
        "rain_prob": 16,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 24.7,
        "humidity": 93,
        "rain_prob": 11,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 24.6,
        "humidity": 95,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 25.6,
        "humidity": 92,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 26.9,
        "humidity": 86,
        "rain_prob": 0,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 28.4,
        "humidity": 77,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 29.7,
        "humidity": 71,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 30.7,
        "humidity": 65,
        "rain_prob": 13,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 31.1,
        "humidity": 62,
        "rain_prob": 28,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 31.4,
        "humidity": 62,
        "rain_prob": 39,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 31.7,
        "humidity": 62,
        "rain_prob": 44,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 30.0,
        "humidity": 72,
        "rain_prob": 45,
        "condition": "thunderstorm"
      },
      {
        "time": "16:00",
        "temp": 29.7,
        "humidity": 70,
        "rain_prob": 43,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 28.8,
        "humidity": 77,
        "rain_prob": 38,
        "condition": "sunny"
      },
      {
        "time": "18:00",
        "temp": 27.7,
        "humidity": 83,
        "rain_prob": 30,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 27.3,
        "humidity": 87,
        "rain_prob": 22,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 26.6,
        "humidity": 92,
        "rain_prob": 16,
        "condition": "light_rain"
      },
      {
        "time": "21:00",
        "temp": 26.6,
        "humidity": 93,
        "rain_prob": 10,
        "condition": "partly_cloudy"
      },
      {
        "time": "22:00",
        "temp": 26.4,
        "humidity": 94,
        "rain_prob": 6,
        "condition": "partly_cloudy"
      },
      {
        "time": "23:00",
        "temp": 26.2,
        "humidity": 95,
        "rain_prob": 3,
        "condition": "partly_cloudy"
      }
    ]
  },
  {
    "id": "VN_AG",
    "name": "An Giang",
    "province": "An Giang",
    "region": "Miền Nam",
    "type": "Tỉnh",
    "lat": 10.3833,
    "lon": 105.4167,
    "condition": "sunny",
    "weather_text": "Trời trong xanh, ít mây, nắng dịu",
    "temp": 32.4,
    "feels_like": 36.8,
    "humidity": 56,
    "wind_speed": 15.0,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 7.7,
    "pressure": 1011,
    "visibility": 14.2,
    "pm25": 12.4,
    "pm10": 15.1,
    "no2": 2.0,
    "co": 0.53,
    "o3": 140.0,
    "so2": 8.4,
    "outdoor_activities": [
      "Du lịch",
      "Chụp ảnh",
      "Đi thuyền"
    ],
    "outdoor_score": 92,
    "best_time": "07:00 - 10:30, 15:30 - 18:00",
    "outdoor_advice": "Check-in rừng tràm Trà Sư thảm bèo xanh mướt, viếng miếu Bà Chúa Xứ núi Sam rất thuận lợi.",
    "station_id": "VN_AG",
    "station_name": "Trạm An Giang",
    "district": "An Giang",
    "latitude": 10.3833,
    "longitude": 105.4167,
    "temperature": 32.4,
    "aqi_level": "Trung bình",
    "color": "#f59e0b",
    "health_advice": "Chất lượng không khí ở mức chấp nhận được đối với đa số người dân.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_AG_01",
        "name": "Trạm TP Long Xuyên - Trung tâm",
        "type": "Đô thị",
        "address": "Đường Hà Hoàng Hổ, P. Mỹ Xuyên",
        "lat": 10.385,
        "lon": 105.42,
        "pm25": 11.2,
        "pm10": 16.8,
        "aqi": 20,
        "temp": 32.0,
        "humidity": 56,
        "wind": 14.6,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_AG",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_AG_02",
        "name": "Trạm TP Châu Đốc - Núi Sam",
        "type": "Du lịch tâm linh biên giới",
        "address": "Phường Núi Sam, TP. Châu Đốc",
        "lat": 10.685,
        "lon": 105.155,
        "pm25": 13.0,
        "pm10": 19.5,
        "aqi": 23,
        "temp": 32.6,
        "humidity": 56,
        "wind": 15.2,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_AG",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_AG_03",
        "name": "Trạm Rừng Tràm Trà Sư",
        "type": "Trạm nền sinh thái rừng ngập phèn",
        "address": "Xã Văn Giáo, TX. Tịnh Biên",
        "lat": 10.512,
        "lon": 105.052,
        "pm25": 12.4,
        "pm10": 18.6,
        "aqi": 22,
        "temp": 32.4,
        "humidity": 53,
        "wind": 15.0,
        "aqi_level": "Trung bình",
        "color": "#f59e0b",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_AG",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.8,
        "humidity": 95,
        "rain_prob": 20,
        "condition": "partly_cloudy"
      },
      {
        "time": "01:00",
        "temp": 25.9,
        "humidity": 88,
        "rain_prob": 20,
        "condition": "partly_cloudy"
      },
      {
        "time": "02:00",
        "temp": 25.0,
        "humidity": 94,
        "rain_prob": 24,
        "condition": "light_rain"
      },
      {
        "time": "03:00",
        "temp": 25.1,
        "humidity": 95,
        "rain_prob": 29,
        "condition": "light_rain"
      },
      {
        "time": "04:00",
        "temp": 25.0,
        "humidity": 96,
        "rain_prob": 31,
        "condition": "overcast"
      },
      {
        "time": "05:00",
        "temp": 24.9,
        "humidity": 97,
        "rain_prob": 24,
        "condition": "overcast"
      },
      {
        "time": "06:00",
        "temp": 24.8,
        "humidity": 96,
        "rain_prob": 13,
        "condition": "overcast"
      },
      {
        "time": "07:00",
        "temp": 25.7,
        "humidity": 91,
        "rain_prob": 4,
        "condition": "partly_cloudy"
      },
      {
        "time": "08:00",
        "temp": 27.3,
        "humidity": 83,
        "rain_prob": 1,
        "condition": "partly_cloudy"
      },
      {
        "time": "09:00",
        "temp": 29.0,
        "humidity": 74,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "10:00",
        "temp": 30.3,
        "humidity": 66,
        "rain_prob": 2,
        "condition": "sunny"
      },
      {
        "time": "11:00",
        "temp": 31.4,
        "humidity": 61,
        "rain_prob": 5,
        "condition": "sunny"
      },
      {
        "time": "12:00",
        "temp": 32.2,
        "humidity": 57,
        "rain_prob": 10,
        "condition": "light_rain"
      },
      {
        "time": "13:00",
        "temp": 32.5,
        "humidity": 56,
        "rain_prob": 20,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 32.5,
        "humidity": 57,
        "rain_prob": 42,
        "condition": "light_rain"
      },
      {
        "time": "15:00",
        "temp": 30.3,
        "humidity": 68,
        "rain_prob": 69,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 26.1,
        "humidity": 87,
        "rain_prob": 86,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 26.5,
        "humidity": 87,
        "rain_prob": 83,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.1,
        "humidity": 92,
        "rain_prob": 70,
        "condition": "sunny"
      },
      {
        "time": "19:00",
        "temp": 25.9,
        "humidity": 93,
        "rain_prob": 55,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 25.7,
        "humidity": 94,
        "rain_prob": 41,
        "condition": "sunny"
      },
      {
        "time": "21:00",
        "temp": 25.7,
        "humidity": 95,
        "rain_prob": 27,
        "condition": "sunny"
      },
      {
        "time": "22:00",
        "temp": 25.6,
        "humidity": 95,
        "rain_prob": 16,
        "condition": "partly_cloudy"
      },
      {
        "time": "23:00",
        "temp": 25.4,
        "humidity": 96,
        "rain_prob": 12,
        "condition": "overcast"
      }
    ]
  },
  {
    "id": "VN_CM",
    "name": "Cà Mau",
    "province": "Cà Mau",
    "region": "Miền Nam",
    "type": "Tỉnh",
    "lat": 9.1769,
    "lon": 105.15,
    "condition": "overcast",
    "weather_text": "Trời nhiều mây, âm u, không khí mát mẻ",
    "temp": 31.6,
    "feels_like": 36.8,
    "humidity": 68,
    "wind_speed": 18.9,
    "wind_dir": "Đông",
    "rain_prob": 5,
    "rain_mm": 0.0,
    "uv": 5.0,
    "pressure": 1010,
    "visibility": 14.3,
    "pm25": 10.2,
    "pm10": 13.4,
    "no2": 2.0,
    "co": 0.3,
    "o3": 95.0,
    "so2": 3.8,
    "outdoor_activities": [
      "Du lịch sinh thái",
      "Chụp ảnh Đất Mũi"
    ],
    "outdoor_score": 91,
    "best_time": "07:30 - 11:00, 14:30 - 17:30",
    "outdoor_advice": "Thời tiết biển lộng gió, cực kỳ trong lành; chụp ảnh cột mốc tọa độ Quốc gia Đất Mũi tráng lệ.",
    "station_id": "VN_CM",
    "station_name": "Trạm Cà Mau",
    "district": "Cà Mau",
    "latitude": 9.1769,
    "longitude": 105.15,
    "temperature": 31.6,
    "aqi_level": "Tốt",
    "color": "#10b981",
    "health_advice": "Chất lượng không khí trong lành, lý tưởng cho mọi hoạt động ngoài trời.",
    "timestamp": "2026-11-08 12:45",
    "stations": [
      {
        "id": "VN_CM_01",
        "name": "Trạm Trung tâm TP Cà Mau",
        "type": "Đô thị",
        "address": "Đường Hùng Vương, P. 5",
        "lat": 9.18,
        "lon": 105.155,
        "pm25": 10.8,
        "pm10": 16.2,
        "aqi": 19,
        "temp": 31.8,
        "humidity": 68,
        "wind": 19.1,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CM",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_CM_02",
        "name": "Trạm Cột Mốc Tọa Độ Đất Mũi",
        "type": "Trạm nền sinh thái cực Nam",
        "address": "Xã Đất Mũi, H. Ngọc Hiển",
        "lat": 8.615,
        "lon": 104.725,
        "pm25": 9.6,
        "pm10": 14.4,
        "aqi": 17,
        "temp": 31.4,
        "humidity": 70,
        "wind": 18.7,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CM",
        "timestamp": "2026-11-08 12:45:43"
      },
      {
        "id": "VN_CM_03",
        "name": "Trạm KCN Khí - Điện - Đạm Cà Mau",
        "type": "Công nghiệp năng lượng",
        "address": "Xã Khánh An, H. U Minh",
        "lat": 9.285,
        "lon": 105.015,
        "pm25": 9.0,
        "pm10": 13.5,
        "aqi": 16,
        "temp": 31.2,
        "humidity": 71,
        "wind": 18.5,
        "aqi_level": "Tốt",
        "color": "#10b981",
        "status": "Đang hoạt động 24/7 (Realtime Live)",
        "province_id": "VN_CM",
        "timestamp": "2026-11-08 12:45:43"
      }
    ],
    "hourly_forecast_24h": [
      {
        "time": "00:00",
        "temp": 25.8,
        "humidity": 91,
        "rain_prob": 20,
        "condition": "sunny"
      },
      {
        "time": "01:00",
        "temp": 26.3,
        "humidity": 89,
        "rain_prob": 16,
        "condition": "sunny"
      },
      {
        "time": "02:00",
        "temp": 26.1,
        "humidity": 90,
        "rain_prob": 14,
        "condition": "overcast"
      },
      {
        "time": "03:00",
        "temp": 26.0,
        "humidity": 90,
        "rain_prob": 12,
        "condition": "overcast"
      },
      {
        "time": "04:00",
        "temp": 25.8,
        "humidity": 91,
        "rain_prob": 10,
        "condition": "light_rain"
      },
      {
        "time": "05:00",
        "temp": 25.4,
        "humidity": 92,
        "rain_prob": 6,
        "condition": "sunny"
      },
      {
        "time": "06:00",
        "temp": 25.2,
        "humidity": 92,
        "rain_prob": 1,
        "condition": "sunny"
      },
      {
        "time": "07:00",
        "temp": 26.3,
        "humidity": 89,
        "rain_prob": 0,
        "condition": "sunny"
      },
      {
        "time": "08:00",
        "temp": 27.6,
        "humidity": 82,
        "rain_prob": 4,
        "condition": "sunny"
      },
      {
        "time": "09:00",
        "temp": 28.6,
        "humidity": 77,
        "rain_prob": 12,
        "condition": "light_rain"
      },
      {
        "time": "10:00",
        "temp": 29.4,
        "humidity": 73,
        "rain_prob": 25,
        "condition": "light_rain"
      },
      {
        "time": "11:00",
        "temp": 30.1,
        "humidity": 74,
        "rain_prob": 47,
        "condition": "light_rain"
      },
      {
        "time": "12:00",
        "temp": 30.8,
        "humidity": 71,
        "rain_prob": 73,
        "condition": "sunny"
      },
      {
        "time": "13:00",
        "temp": 31.4,
        "humidity": 69,
        "rain_prob": 92,
        "condition": "light_rain"
      },
      {
        "time": "14:00",
        "temp": 27.5,
        "humidity": 87,
        "rain_prob": 98,
        "condition": "thunderstorm"
      },
      {
        "time": "15:00",
        "temp": 27.5,
        "humidity": 85,
        "rain_prob": 97,
        "condition": "light_rain"
      },
      {
        "time": "16:00",
        "temp": 26.7,
        "humidity": 85,
        "rain_prob": 90,
        "condition": "light_rain"
      },
      {
        "time": "17:00",
        "temp": 26.5,
        "humidity": 88,
        "rain_prob": 76,
        "condition": "light_rain"
      },
      {
        "time": "18:00",
        "temp": 26.2,
        "humidity": 89,
        "rain_prob": 58,
        "condition": "partly_cloudy"
      },
      {
        "time": "19:00",
        "temp": 26.4,
        "humidity": 88,
        "rain_prob": 41,
        "condition": "sunny"
      },
      {
        "time": "20:00",
        "temp": 26.6,
        "humidity": 87,
        "rain_prob": 28,
        "condition": "partly_cloudy"
      },
      {
        "time": "21:00",
        "temp": 26.8,
        "humidity": 86,
        "rain_prob": 17,
        "condition": "overcast"
      },
      {
        "time": "22:00",
        "temp": 26.7,
        "humidity": 85,
        "rain_prob": 10,
        "condition": "overcast"
      },
      {
        "time": "23:00",
        "temp": 26.6,
        "humidity": 85,
        "rain_prob": 9,
        "condition": "overcast"
      }
    ]
  }
]

STATIONS_CONFIG = {
  "VN_HN": [
    {
      "id": "VN_HN_01",
      "name": "Trạm Ba Đình - Trung tâm Hành chính",
      "type": "Đô thị / Hành chính",
      "address": "Số 1 Hoàng Hoa Thám, P. Ba Đình",
      "lat": 21.0342,
      "lon": 105.836,
      "pm25": 11.0,
      "pm10": 16.5,
      "aqi": 20,
      "temp": 26.2,
      "humidity": 82,
      "wind": 1.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_02",
      "name": "Trạm Hoàn Kiếm - Phố Cổ",
      "type": "Dân cư / Thương mại",
      "address": "Số 2 Hàng Trống, P. Hàng Trống",
      "lat": 21.0289,
      "lon": 105.8524,
      "pm25": 12.2,
      "pm10": 18.3,
      "aqi": 22,
      "temp": 26.6,
      "humidity": 82,
      "wind": 2.3,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_03",
      "name": "Trạm Cầu Giấy - Giao thông",
      "type": "Giao thông huyết mạch",
      "address": "Đường Cầu Giấy, P. Dịch Vọng",
      "lat": 21.0365,
      "lon": 105.7952,
      "pm25": 11.0,
      "pm10": 16.5,
      "aqi": 20,
      "temp": 26.2,
      "humidity": 83,
      "wind": 1.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_04",
      "name": "Trạm Đống Đa - Nguyễn Lương Bằng",
      "type": "Khu dân cư mật độ cao",
      "address": "Đường Nguyễn Lương Bằng, Q. Đống Đa",
      "lat": 21.0189,
      "lon": 105.8267,
      "pm25": 11.0,
      "pm10": 16.5,
      "aqi": 20,
      "temp": 26.2,
      "humidity": 79,
      "wind": 1.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_05",
      "name": "Trạm Hai Bà Trưng - Minh Khai",
      "type": "Giao thông và dân cư",
      "address": "Đường Minh Khai, Q. Hai Bà Trưng",
      "lat": 21.0025,
      "lon": 105.8569,
      "pm25": 11.0,
      "pm10": 16.5,
      "aqi": 20,
      "temp": 26.2,
      "humidity": 78,
      "wind": 1.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_06",
      "name": "Trạm Tây Hồ - Lạc Long Quân",
      "type": "Đô thị sinh thái hồ",
      "address": "Đường Lạc Long Quân, Q. Tây Hồ",
      "lat": 21.0652,
      "lon": 105.8123,
      "pm25": 9.8,
      "pm10": 14.7,
      "aqi": 18,
      "temp": 25.8,
      "humidity": 77,
      "wind": 1.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_07",
      "name": "Trạm Long Biên - Nguyễn Văn Cừ",
      "type": "Khu cửa ngõ phía Đông",
      "address": "Đường Nguyễn Văn Cừ, Q. Long Biên",
      "lat": 21.0489,
      "lon": 105.8785,
      "pm25": 11.0,
      "pm10": 16.5,
      "aqi": 20,
      "temp": 26.2,
      "humidity": 78,
      "wind": 1.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HN_08",
      "name": "Trạm Hà Đông - Quang Trung",
      "type": "Khu đô thị vệ tinh",
      "address": "Đường Quang Trung, Q. Hà Đông",
      "lat": 20.9712,
      "lon": 105.7725,
      "pm25": 10.4,
      "pm10": 15.6,
      "aqi": 19,
      "temp": 26.0,
      "humidity": 79,
      "wind": 1.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HN",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_HP": [
    {
      "id": "VN_HP_01",
      "name": "Trạm Tam Bạc - Q. Hồng Bàng",
      "type": "Đô thị / Trung tâm",
      "address": "Đường Tam Bạc, P. Phan Bội Châu",
      "lat": 20.8601,
      "lon": 106.6782,
      "pm25": 6.1,
      "pm10": 9.1,
      "aqi": 11,
      "temp": 28.7,
      "humidity": 72,
      "wind": 16.4,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HP",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HP_02",
      "name": "Trạm KCN Đình Vũ - Cảng biển",
      "type": "Công nghiệp / Cảng",
      "address": "Bán đảo Đình Vũ, Q. Hải An",
      "lat": 20.8415,
      "lon": 106.7582,
      "pm25": 5.5,
      "pm10": 8.2,
      "aqi": 10,
      "temp": 28.5,
      "humidity": 70,
      "wind": 16.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HP",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HP_03",
      "name": "Trạm Đồ Sơn - Sinh thái Ven biển",
      "type": "Sinh thái biển",
      "address": "Khu 2 Đồ Sơn, Q. Đồ Sơn",
      "lat": 20.7125,
      "lon": 106.7891,
      "pm25": 4.9,
      "pm10": 7.4,
      "aqi": 9,
      "temp": 28.3,
      "humidity": 68,
      "wind": 16.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HP",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_CB": [
    {
      "id": "VN_CB_01",
      "name": "Trạm Trung tâm TP Cao Bằng",
      "type": "Đô thị",
      "address": "Đường Kim Đồng, P. Hợp Giang",
      "lat": 22.668,
      "lon": 106.255,
      "pm25": 7.1,
      "pm10": 10.6,
      "aqi": 13,
      "temp": 26.2,
      "humidity": 81,
      "wind": 6.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CB",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_CB_02",
      "name": "Trạm Thác Bản Giốc - Trùng Khánh",
      "type": "Sinh thái du lịch",
      "address": "Xã Đàm Thủy, H. Trùng Khánh",
      "lat": 22.854,
      "lon": 106.723,
      "pm25": 4.7,
      "pm10": 7.1,
      "aqi": 8,
      "temp": 25.4,
      "humidity": 80,
      "wind": 5.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CB",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_TQ": [
    {
      "id": "VN_TQ_01",
      "name": "Trạm Trung tâm TP Tuyên Quang",
      "type": "Đô thị",
      "address": "Đường Tân Trào, P. Phan Thiết",
      "lat": 21.824,
      "lon": 105.217,
      "pm25": 11.7,
      "pm10": 17.5,
      "aqi": 21,
      "temp": 24.5,
      "humidity": 91,
      "wind": 3.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TQ",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TQ_02",
      "name": "Trạm Hồ Sinh thái Na Hang",
      "type": "Trạm nền sinh thái",
      "address": "Thị trấn Na Hang, H. Na Hang",
      "lat": 22.348,
      "lon": 105.385,
      "pm25": 12.3,
      "pm10": 18.5,
      "aqi": 22,
      "temp": 24.7,
      "humidity": 93,
      "wind": 3.7,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TQ",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_DB": [
    {
      "id": "VN_DB_01",
      "name": "Trạm Di tích TP Điện Biên Phủ",
      "type": "Đô thị / Văn hóa",
      "address": "Đường Võ Nguyên Giáp, P. Mường Thanh",
      "lat": 21.388,
      "lon": 103.021,
      "pm25": 6.1,
      "pm10": 9.1,
      "aqi": 11,
      "temp": 29.4,
      "humidity": 58,
      "wind": 10.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DB",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DB_02",
      "name": "Trạm Cửa khẩu Tây Trang",
      "type": "Giao thông biên giới",
      "address": "Xã Na Ư, H. Điện Biên",
      "lat": 21.215,
      "lon": 102.915,
      "pm25": 7.3,
      "pm10": 10.9,
      "aqi": 13,
      "temp": 29.8,
      "humidity": 56,
      "wind": 10.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DB",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_LC": [
    {
      "id": "VN_LC_01",
      "name": "Trạm Quảng trường TP Lai Châu",
      "type": "Đô thị",
      "address": "Đường Trần Phú, P. Tân Phong",
      "lat": 22.398,
      "lon": 103.461,
      "pm25": 4.4,
      "pm10": 6.6,
      "aqi": 8,
      "temp": 24.7,
      "humidity": 70,
      "wind": 4.6,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LC",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_LC_02",
      "name": "Trạm Đèo Ô Quy Hồ",
      "type": "Trạm nền núi cao",
      "address": "Đèo Ô Quy Hồ, H. Tam Đường",
      "lat": 22.355,
      "lon": 103.778,
      "pm25": 3.2,
      "pm10": 4.8,
      "aqi": 6,
      "temp": 24.3,
      "humidity": 73,
      "wind": 4.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LC",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_SL": [
    {
      "id": "VN_SL_01",
      "name": "Trạm Trung tâm TP Sơn La",
      "type": "Đô thị",
      "address": "Đường Tô Hiệu, P. Chiềng Lề",
      "lat": 21.33,
      "lon": 103.918,
      "pm25": 5.7,
      "pm10": 8.6,
      "aqi": 10,
      "temp": 25.5,
      "humidity": 79,
      "wind": 11.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_SL",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_SL_02",
      "name": "Trạm Cao nguyên Mộc Châu",
      "type": "Sinh thái nông nghiệp",
      "address": "Thị trấn Nông trường Mộc Châu",
      "lat": 20.842,
      "lon": 104.654,
      "pm25": 6.3,
      "pm10": 9.4,
      "aqi": 11,
      "temp": 25.7,
      "humidity": 79,
      "wind": 12.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_SL",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_LCAI": [
    {
      "id": "VN_LCAI_01",
      "name": "Trạm TP Lào Cai - Cửa khẩu",
      "type": "Đô thị biên giới",
      "address": "Đường Hoàng Liên, P. Cốc Lếu",
      "lat": 22.489,
      "lon": 103.968,
      "pm25": 4.3,
      "pm10": 6.4,
      "aqi": 8,
      "temp": 25.9,
      "humidity": 74,
      "wind": 6.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LCAI",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_LCAI_02",
      "name": "Trạm Sa Pa - Đỉnh Fansipan",
      "type": "Sinh thái núi cao",
      "address": "Thị xã Sa Pa",
      "lat": 22.336,
      "lon": 103.844,
      "pm25": 6.7,
      "pm10": 10.1,
      "aqi": 12,
      "temp": 26.7,
      "humidity": 74,
      "wind": 7.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LCAI",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_TN": [
    {
      "id": "VN_TN_01",
      "name": "Trạm Trung tâm TP Thái Nguyên",
      "type": "Đô thị",
      "address": "Đường Lương Ngọc Quyến, P. Quang Trung",
      "lat": 21.596,
      "lon": 105.845,
      "pm25": 9.0,
      "pm10": 13.5,
      "aqi": 16,
      "temp": 26.8,
      "humidity": 77,
      "wind": 6.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TN_02",
      "name": "Trạm KCN Yên Bình (Samsung)",
      "type": "Công nghiệp",
      "address": "Phường Đồng Tiến, TX. Phổ Yên",
      "lat": 21.432,
      "lon": 105.885,
      "pm25": 8.4,
      "pm10": 12.6,
      "aqi": 15,
      "temp": 26.6,
      "humidity": 82,
      "wind": 5.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TN_03",
      "name": "Trạm Sinh thái Hồ Núi Cốc",
      "type": "Trạm nền sinh thái",
      "address": "Xã Tân Thái, H. Đại Từ",
      "lat": 21.602,
      "lon": 105.715,
      "pm25": 10.2,
      "pm10": 15.3,
      "aqi": 18,
      "temp": 27.2,
      "humidity": 81,
      "wind": 6.4,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TN",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_LS": [
    {
      "id": "VN_LS_01",
      "name": "Trạm TP Lạng Sơn - Tam Thanh",
      "type": "Đô thị",
      "address": "Đường Lê Lợi, P. Vĩnh Trại",
      "lat": 21.855,
      "lon": 106.76,
      "pm25": 4.6,
      "pm10": 6.9,
      "aqi": 8,
      "temp": 25.6,
      "humidity": 80,
      "wind": 9.3,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LS",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_LS_02",
      "name": "Trạm Cửa khẩu Quốc tế Hữu Nghị",
      "type": "Giao thông biên giới",
      "address": "Thị trấn Đồng Đăng, H. Cao Lộc",
      "lat": 21.985,
      "lon": 106.712,
      "pm25": 5.2,
      "pm10": 7.8,
      "aqi": 9,
      "temp": 25.8,
      "humidity": 80,
      "wind": 9.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LS",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_LS_03",
      "name": "Trạm Khí tượng Đỉnh Mẫu Sơn",
      "type": "Trạm nền núi cao",
      "address": "Khu du lịch Mẫu Sơn, H. Lộc Bình",
      "lat": 21.848,
      "lon": 106.915,
      "pm25": 5.8,
      "pm10": 8.7,
      "aqi": 10,
      "temp": 26.0,
      "humidity": 82,
      "wind": 9.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LS",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_QN": [
    {
      "id": "VN_QN_01",
      "name": "Trạm Bãi Cháy - Hạ Long",
      "type": "Đô thị du lịch ven biển",
      "address": "Đường Hạ Long, P. Bãi Cháy",
      "lat": 20.958,
      "lon": 107.035,
      "pm25": 7.9,
      "pm10": 11.9,
      "aqi": 14,
      "temp": 28.7,
      "humidity": 68,
      "wind": 20.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_QN_02",
      "name": "Trạm Cẩm Phả - Vùng khai thác",
      "type": "Công nghiệp khai khoáng",
      "address": "Đường Trần Phú, P. Cẩm Thành",
      "lat": 21.018,
      "lon": 107.288,
      "pm25": 6.7,
      "pm10": 10.1,
      "aqi": 12,
      "temp": 28.3,
      "humidity": 69,
      "wind": 19.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_QN_03",
      "name": "Trạm Vân Đồn - Sân bay & Đảo",
      "type": "Sinh thái biển đảo",
      "address": "Huyện Vân Đồn",
      "lat": 21.125,
      "lon": 107.412,
      "pm25": 6.7,
      "pm10": 10.1,
      "aqi": 12,
      "temp": 28.3,
      "humidity": 67,
      "wind": 19.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QN",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_BN": [
    {
      "id": "VN_BN_01",
      "name": "Trạm TP Bắc Ninh - Đền Đô",
      "type": "Đô thị văn hóa",
      "address": "Đường Ngô Gia Tự, P. Tiền An",
      "lat": 21.189,
      "lon": 106.072,
      "pm25": 12.2,
      "pm10": 18.3,
      "aqi": 22,
      "temp": 28.9,
      "humidity": 70,
      "wind": 6.8,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_BN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_BN_02",
      "name": "Trạm KCN Quế Võ",
      "type": "Công nghiệp",
      "address": "KCN Quế Võ, TX. Quế Võ",
      "lat": 21.162,
      "lon": 106.145,
      "pm25": 9.8,
      "pm10": 14.7,
      "aqi": 18,
      "temp": 28.1,
      "humidity": 67,
      "wind": 6.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_BN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_BN_03",
      "name": "Trạm KCN Yên Phong",
      "type": "Công nghiệp công nghệ cao",
      "address": "KCN Yên Phong, H. Yên Phong",
      "lat": 21.225,
      "lon": 105.985,
      "pm25": 10.4,
      "pm10": 15.6,
      "aqi": 19,
      "temp": 28.3,
      "humidity": 68,
      "wind": 6.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_BN",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_PT": [
    {
      "id": "VN_PT_01",
      "name": "Trạm TP Việt Trì - Trung tâm",
      "type": "Đô thị",
      "address": "Đường Hùng Vương, P. Gia Cẩm",
      "lat": 21.318,
      "lon": 105.412,
      "pm25": 15.5,
      "pm10": 23.2,
      "aqi": 28,
      "temp": 26.6,
      "humidity": 79,
      "wind": 4.3,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_PT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_PT_02",
      "name": "Trạm Khu Di tích Đền Hùng",
      "type": "Trạm nền văn hóa lịch sử",
      "address": "Khu di tích lịch sử Đền Hùng",
      "lat": 21.378,
      "lon": 105.335,
      "pm25": 14.9,
      "pm10": 22.4,
      "aqi": 27,
      "temp": 26.4,
      "humidity": 77,
      "wind": 4.1,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_PT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_PT_03",
      "name": "Trạm KCN Thụy Vân",
      "type": "Công nghiệp",
      "address": "KCN Thụy Vân, TP. Việt Trì",
      "lat": 21.345,
      "lon": 105.378,
      "pm25": 14.3,
      "pm10": 21.5,
      "aqi": 26,
      "temp": 26.2,
      "humidity": 80,
      "wind": 3.9,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_PT",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_HY": [
    {
      "id": "VN_HY_01",
      "name": "Trạm TP Hưng Yên - Phố Hiến",
      "type": "Đô thị cổ",
      "address": "Đường Bãi Sậy, P. Quang Trung",
      "lat": 20.648,
      "lon": 106.053,
      "pm25": 14.4,
      "pm10": 21.6,
      "aqi": 26,
      "temp": 26.9,
      "humidity": 86,
      "wind": 2.4,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HY",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HY_02",
      "name": "Trạm KCN Phố Nối A",
      "type": "Công nghiệp",
      "address": "Huyện Văn Lâm & Mỹ Hào",
      "lat": 20.935,
      "lon": 106.035,
      "pm25": 14.4,
      "pm10": 21.6,
      "aqi": 26,
      "temp": 26.9,
      "humidity": 88,
      "wind": 2.4,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HY",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HY_03",
      "name": "Trạm Sinh thái Ecopark",
      "type": "Đô thị sinh thái",
      "address": "Khu đô thị Ecopark, Văn Giang",
      "lat": 20.965,
      "lon": 105.932,
      "pm25": 13.2,
      "pm10": 19.8,
      "aqi": 24,
      "temp": 26.5,
      "humidity": 84,
      "wind": 2.0,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HY",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_NB": [
    {
      "id": "VN_NB_01",
      "name": "Trạm Trung tâm TP Ninh Bình",
      "type": "Đô thị",
      "address": "Đường Lê Thái Tổ, P. Đông Thành",
      "lat": 20.255,
      "lon": 105.978,
      "pm25": 11.2,
      "pm10": 16.8,
      "aqi": 20,
      "temp": 25.9,
      "humidity": 82,
      "wind": 11.6,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_NB",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_NB_02",
      "name": "Trạm Di sản Tràng An - Tam Cốc",
      "type": "Trạm nền di sản thiên nhiên",
      "address": "Quần thể danh thắng Tràng An",
      "lat": 20.258,
      "lon": 105.908,
      "pm25": 12.4,
      "pm10": 18.6,
      "aqi": 22,
      "temp": 26.3,
      "humidity": 79,
      "wind": 12.0,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_NB",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_NB_03",
      "name": "Trạm KCN Gián Khẩu",
      "type": "Công nghiệp",
      "address": "Huyện Gia Viễn",
      "lat": 20.325,
      "lon": 105.912,
      "pm25": 11.8,
      "pm10": 17.7,
      "aqi": 21,
      "temp": 26.1,
      "humidity": 84,
      "wind": 11.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_NB",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_TH": [
    {
      "id": "VN_TH_01",
      "name": "Trạm Trung tâm TP Thanh Hóa",
      "type": "Đô thị",
      "address": "Đường Trần Phú, P. Điện Biên",
      "lat": 19.812,
      "lon": 105.782,
      "pm25": 10.7,
      "pm10": 16.0,
      "aqi": 19,
      "temp": 27.9,
      "humidity": 75,
      "wind": 15.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TH_02",
      "name": "Trạm Du lịch Biển Sầm Sơn",
      "type": "Ven biển",
      "address": "Đường Hồ Xuân Hương, TP. Sầm Sơn",
      "lat": 19.745,
      "lon": 105.905,
      "pm25": 9.5,
      "pm10": 14.2,
      "aqi": 17,
      "temp": 27.5,
      "humidity": 77,
      "wind": 15.3,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TH_03",
      "name": "Trạm KKT Nghi Sơn",
      "type": "Công nghiệp nặng & Lọc dầu",
      "address": "Khu kinh tế Nghi Sơn, TX. Nghi Sơn",
      "lat": 19.345,
      "lon": 105.785,
      "pm25": 10.1,
      "pm10": 15.1,
      "aqi": 18,
      "temp": 27.7,
      "humidity": 80,
      "wind": 15.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TH",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_NA": [
    {
      "id": "VN_NA_01",
      "name": "Trạm Trung tâm TP Vinh",
      "type": "Đô thị",
      "address": "Đường Lê Mao, P. Lê Mao",
      "lat": 18.675,
      "lon": 105.684,
      "pm25": 11.1,
      "pm10": 16.6,
      "aqi": 20,
      "temp": 25.9,
      "humidity": 83,
      "wind": 10.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_NA",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_NA_02",
      "name": "Trạm Quê Bác - Nam Đàn",
      "type": "Trạm nền văn hóa",
      "address": "Khu di tích Kim Liên, H. Nam Đàn",
      "lat": 18.685,
      "lon": 105.545,
      "pm25": 12.3,
      "pm10": 18.5,
      "aqi": 22,
      "temp": 26.3,
      "humidity": 80,
      "wind": 11.2,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_NA",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_NA_03",
      "name": "Trạm Thị xã Biển Cửa Lò",
      "type": "Ven biển",
      "address": "Đường Bình Minh, TX. Cửa Lò",
      "lat": 18.805,
      "lon": 105.725,
      "pm25": 12.3,
      "pm10": 18.5,
      "aqi": 22,
      "temp": 26.3,
      "humidity": 85,
      "wind": 11.2,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_NA",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_HT": [
    {
      "id": "VN_HT_01",
      "name": "Trạm Trung tâm TP Hà Tĩnh",
      "type": "Đô thị",
      "address": "Đường Phan Đình Phùng, P. Bắc Hà",
      "lat": 18.345,
      "lon": 105.908,
      "pm25": 9.9,
      "pm10": 14.9,
      "aqi": 18,
      "temp": 28.5,
      "humidity": 70,
      "wind": 11.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HT_02",
      "name": "Trạm KKT Vũng Áng - Formosa",
      "type": "Công nghiệp nặng",
      "address": "Khu kinh tế Vũng Áng, TX. Kỳ Anh",
      "lat": 18.065,
      "lon": 106.385,
      "pm25": 10.5,
      "pm10": 15.8,
      "aqi": 19,
      "temp": 28.7,
      "humidity": 70,
      "wind": 11.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HT_03",
      "name": "Trạm Khu Di tích Ngã ba Đồng Lộc",
      "type": "Trạm nền lịch sử",
      "address": "Huyện Can Lộc",
      "lat": 18.425,
      "lon": 105.752,
      "pm25": 8.1,
      "pm10": 12.1,
      "aqi": 15,
      "temp": 27.9,
      "humidity": 71,
      "wind": 10.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HT",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_QT": [
    {
      "id": "VN_QT_01",
      "name": "Trạm TP Đông Hà",
      "type": "Đô thị",
      "address": "Đường Hùng Vương, P. 1",
      "lat": 16.822,
      "lon": 107.098,
      "pm25": 6.1,
      "pm10": 9.1,
      "aqi": 11,
      "temp": 28.3,
      "humidity": 74,
      "wind": 16.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_QT_02",
      "name": "Trạm TX Quảng Trị - Thành Cổ",
      "type": "Văn hóa di tích",
      "address": "Đường Hai Bà Trưng, P. 2",
      "lat": 16.748,
      "lon": 107.185,
      "pm25": 4.9,
      "pm10": 7.4,
      "aqi": 9,
      "temp": 27.9,
      "humidity": 77,
      "wind": 15.6,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_QT_03",
      "name": "Trạm Cửa khẩu Quốc tế Lao Bảo",
      "type": "Giao thông biên giới",
      "address": "Thị trấn Lao Bảo, H. Hướng Hóa",
      "lat": 16.615,
      "lon": 106.592,
      "pm25": 6.1,
      "pm10": 9.1,
      "aqi": 11,
      "temp": 28.3,
      "humidity": 75,
      "wind": 16.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QT",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_HUE": [
    {
      "id": "VN_HUE_01",
      "name": "Trạm Đại Nội - Trung tâm Cố Đô",
      "type": "Đô thị di sản",
      "address": "Đường Đoàn Thị Điểm, P. Thuận Thành",
      "lat": 16.469,
      "lon": 107.578,
      "pm25": 4.3,
      "pm10": 6.4,
      "aqi": 8,
      "temp": 28.9,
      "humidity": 73,
      "wind": 12.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HUE",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HUE_02",
      "name": "Trạm Phố đi bộ Nguyễn Đình Chiểu",
      "type": "Du lịch ven sông Hương",
      "address": "Bờ sông Hương, P. Vĩnh Ninh",
      "lat": 16.462,
      "lon": 107.589,
      "pm25": 5.5,
      "pm10": 8.2,
      "aqi": 10,
      "temp": 29.3,
      "humidity": 72,
      "wind": 12.4,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HUE",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HUE_03",
      "name": "Trạm KCN Phú Bài & Sân bay",
      "type": "Giao thông công nghiệp",
      "address": "TX. Hương Thủy",
      "lat": 16.398,
      "lon": 107.698,
      "pm25": 4.9,
      "pm10": 7.4,
      "aqi": 9,
      "temp": 29.1,
      "humidity": 73,
      "wind": 12.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HUE",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_DN": [
    {
      "id": "VN_DN_01",
      "name": "Trạm Hải Châu - Cầu Rồng",
      "type": "Đô thị trung tâm",
      "address": "Đường Bạch Đằng, Q. Hải Châu",
      "lat": 16.062,
      "lon": 108.223,
      "pm25": 11.5,
      "pm10": 17.2,
      "aqi": 21,
      "temp": 29.7,
      "humidity": 64,
      "wind": 12.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DN_02",
      "name": "Trạm Bán đảo Sinh thái Sơn Trà",
      "type": "Trạm nền sinh thái rừng biển",
      "address": "Bán đảo Sơn Trà, Q. Sơn Trà",
      "lat": 16.115,
      "lon": 108.275,
      "pm25": 11.5,
      "pm10": 17.2,
      "aqi": 21,
      "temp": 29.7,
      "humidity": 63,
      "wind": 12.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DN_03",
      "name": "Trạm KCN Hòa Khánh - Liên Chiểu",
      "type": "Công nghiệp",
      "address": "KCN Hòa Khánh, Q. Liên Chiểu",
      "lat": 16.072,
      "lon": 108.145,
      "pm25": 11.5,
      "pm10": 17.2,
      "aqi": 21,
      "temp": 29.7,
      "humidity": 63,
      "wind": 12.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DN",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DN_04",
      "name": "Trạm Bãi biển Mỹ Khê",
      "type": "Du lịch ven biển",
      "address": "Đường Võ Nguyên Giáp, Q. Ngũ Hành Sơn",
      "lat": 16.048,
      "lon": 108.245,
      "pm25": 10.9,
      "pm10": 16.4,
      "aqi": 20,
      "temp": 29.5,
      "humidity": 68,
      "wind": 11.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DN",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_QNG": [
    {
      "id": "VN_QNG_01",
      "name": "Trạm Trung tâm TP Quảng Ngãi",
      "type": "Đô thị",
      "address": "Đường Quang Trung, P. Lê Hồng Phong",
      "lat": 15.122,
      "lon": 108.795,
      "pm25": 8.7,
      "pm10": 13.0,
      "aqi": 16,
      "temp": 30.1,
      "humidity": 62,
      "wind": 11.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QNG",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_QNG_02",
      "name": "Trạm KKT Dung Quất - Lọc dầu",
      "type": "Công nghiệp nặng & Lọc dầu",
      "address": "Khu kinh tế Dung Quất, H. Bình Sơn",
      "lat": 15.412,
      "lon": 108.785,
      "pm25": 10.5,
      "pm10": 15.8,
      "aqi": 19,
      "temp": 30.7,
      "humidity": 62,
      "wind": 12.3,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QNG",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_QNG_03",
      "name": "Trạm Đảo Sinh thái Lý Sơn",
      "type": "Sinh thái biển đảo",
      "address": "Huyện đảo Lý Sơn",
      "lat": 15.378,
      "lon": 109.125,
      "pm25": 11.1,
      "pm10": 16.6,
      "aqi": 20,
      "temp": 30.9,
      "humidity": 61,
      "wind": 12.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_QNG",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_KH": [
    {
      "id": "VN_KH_01",
      "name": "Trạm Bờ biển Trần Phú - Nha Trang",
      "type": "Đô thị du lịch",
      "address": "Đường Trần Phú, TP. Nha Trang",
      "lat": 12.242,
      "lon": 109.198,
      "pm25": 10.5,
      "pm10": 15.8,
      "aqi": 19,
      "temp": 30.5,
      "humidity": 58,
      "wind": 22.0,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_KH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_KH_02",
      "name": "Trạm Bán đảo Cam Ranh & Sân bay",
      "type": "Giao thông ven vịnh",
      "address": "TP. Cam Ranh",
      "lat": 11.995,
      "lon": 109.135,
      "pm25": 9.9,
      "pm10": 14.9,
      "aqi": 18,
      "temp": 30.3,
      "humidity": 58,
      "wind": 21.8,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_KH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_KH_03",
      "name": "Trạm Đảo Hòn Tre - Vinpearl",
      "type": "Sinh thái đảo",
      "address": "Vịnh Nha Trang",
      "lat": 12.215,
      "lon": 109.255,
      "pm25": 8.1,
      "pm10": 12.1,
      "aqi": 15,
      "temp": 29.7,
      "humidity": 61,
      "wind": 21.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_KH",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_GL": [
    {
      "id": "VN_GL_01",
      "name": "Trạm Pleiku - Quảng trường Đại Đoàn Kết",
      "type": "Đô thị cao nguyên",
      "address": "Đường Trần Hưng Đạo, P. Tây Sơn",
      "lat": 13.985,
      "lon": 108.005,
      "pm25": 4.3,
      "pm10": 6.4,
      "aqi": 8,
      "temp": 27.7,
      "humidity": 53,
      "wind": 21.6,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_GL",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_GL_02",
      "name": "Trạm Thắng cảnh Biển Hồ (Tơ Nưng)",
      "type": "Trạm nền sinh thái hồ",
      "address": "Xã Biển Hồ, TP. Pleiku",
      "lat": 14.048,
      "lon": 108.002,
      "pm25": 3.1,
      "pm10": 4.7,
      "aqi": 6,
      "temp": 27.3,
      "humidity": 57,
      "wind": 21.2,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_GL",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_GL_03",
      "name": "Trạm Rừng Quốc gia Kon Ka Kinh",
      "type": "Trạm nền rừng đặc dụng",
      "address": "Huyện Mang Yang",
      "lat": 14.315,
      "lon": 108.385,
      "pm25": 3.7,
      "pm10": 5.6,
      "aqi": 7,
      "temp": 27.5,
      "humidity": 57,
      "wind": 21.4,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_GL",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_DLAK": [
    {
      "id": "VN_DLAK_01",
      "name": "Trạm Buôn Ma Thuột - Thủ phủ Cà phê",
      "type": "Đô thị",
      "address": "Đường Lê Duẩn, P. Tân Thành",
      "lat": 12.671,
      "lon": 108.048,
      "pm25": 6.1,
      "pm10": 9.1,
      "aqi": 11,
      "temp": 30.0,
      "humidity": 58,
      "wind": 21.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DLAK",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DLAK_02",
      "name": "Trạm Sinh thái Hồ Lắk",
      "type": "Sinh thái hồ nước",
      "address": "Thị trấn Liên Sơn, H. Lắk",
      "lat": 12.415,
      "lon": 108.185,
      "pm25": 6.7,
      "pm10": 10.1,
      "aqi": 12,
      "temp": 30.2,
      "humidity": 55,
      "wind": 21.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DLAK",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DLAK_03",
      "name": "Trạm KCN Hòa Phú",
      "type": "Công nghiệp",
      "address": "Xã Hòa Phú, TP. Buôn Ma Thuột",
      "lat": 12.585,
      "lon": 107.955,
      "pm25": 4.9,
      "pm10": 7.4,
      "aqi": 9,
      "temp": 29.6,
      "humidity": 57,
      "wind": 21.3,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DLAK",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_LD": [
    {
      "id": "VN_LD_01",
      "name": "Trạm Hồ Xuân Hương - Đà Lạt",
      "type": "Đô thị ngàn hoa",
      "address": "Đường Trần Quốc Toản, P. 1, TP. Đà Lạt",
      "lat": 11.944,
      "lon": 108.448,
      "pm25": 5.4,
      "pm10": 8.1,
      "aqi": 10,
      "temp": 24.4,
      "humidity": 62,
      "wind": 21.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LD",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_LD_02",
      "name": "Trạm Đèo Prenn - Rừng thông",
      "type": "Trạm nền sinh thái rừng thông",
      "address": "Đèo Prenn, TP. Đà Lạt",
      "lat": 11.895,
      "lon": 108.442,
      "pm25": 4.2,
      "pm10": 6.3,
      "aqi": 8,
      "temp": 24.0,
      "humidity": 63,
      "wind": 21.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LD",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_LD_03",
      "name": "Trạm TP Bảo Lộc - Vùng Đồi Chè",
      "type": "Đô thị cao nguyên trà",
      "address": "Đường Lê Hồng Phong, TP. Bảo Lộc",
      "lat": 11.545,
      "lon": 107.805,
      "pm25": 4.8,
      "pm10": 7.2,
      "aqi": 9,
      "temp": 24.2,
      "humidity": 58,
      "wind": 21.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_LD",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_HCM": [
    {
      "id": "VN_HCM_01",
      "name": "Trạm Bến Nghé - Quận 1",
      "type": "Đô thị trung tâm hành chính",
      "address": "Đường Nguyễn Huệ, P. Bến Nghé, Q. 1",
      "lat": 10.775,
      "lon": 106.704,
      "pm25": 16.2,
      "pm10": 24.3,
      "aqi": 29,
      "temp": 32.4,
      "humidity": 54,
      "wind": 7.8,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HCM",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HCM_02",
      "name": "Trạm Ngã tư Hàng Xanh - Bình Thạnh",
      "type": "Giao thông mật độ cao",
      "address": "Ngã tư Hàng Xanh, Q. Bình Thạnh",
      "lat": 10.802,
      "lon": 106.712,
      "pm25": 16.2,
      "pm10": 24.3,
      "aqi": 29,
      "temp": 32.4,
      "humidity": 58,
      "wind": 7.8,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HCM",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HCM_03",
      "name": "Trạm TP Thủ Đức - KCNC",
      "type": "Đô thị sáng tạo công nghệ",
      "address": "Đường D1, Khu CNC, TP. Thủ Đức",
      "lat": 10.854,
      "lon": 106.795,
      "pm25": 17.4,
      "pm10": 26.1,
      "aqi": 31,
      "temp": 32.8,
      "humidity": 54,
      "wind": 8.2,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HCM",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HCM_04",
      "name": "Trạm KCN Tân Bình - Bình Chánh",
      "type": "Công nghiệp",
      "address": "KCN Tân Bình & Bình Chánh",
      "lat": 10.812,
      "lon": 106.625,
      "pm25": 18.0,
      "pm10": 27.0,
      "aqi": 32,
      "temp": 33.0,
      "humidity": 58,
      "wind": 8.4,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HCM",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_HCM_05",
      "name": "Trạm Sinh thái Cần Giờ",
      "type": "Trạm nền sinh thái rừng ngập mặn",
      "address": "Xã Long Hòa, H. Cần Giờ",
      "lat": 10.415,
      "lon": 106.915,
      "pm25": 16.8,
      "pm10": 25.2,
      "aqi": 30,
      "temp": 32.6,
      "humidity": 59,
      "wind": 8.0,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_HCM",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_DNAI": [
    {
      "id": "VN_DNAI_01",
      "name": "Trạm TP Biên Hòa - Trung tâm",
      "type": "Đô thị",
      "address": "Đường 30/4, P. Thanh Bình",
      "lat": 10.959,
      "lon": 106.839,
      "pm25": 15.6,
      "pm10": 23.4,
      "aqi": 28,
      "temp": 31.5,
      "humidity": 66,
      "wind": 5.9,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DNAI",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DNAI_02",
      "name": "Trạm KCN Biên Hòa 2 & Amata",
      "type": "Công nghiệp",
      "address": "KCN Biên Hòa 2, TP. Biên Hòa",
      "lat": 10.925,
      "lon": 106.885,
      "pm25": 16.8,
      "pm10": 25.2,
      "aqi": 30,
      "temp": 31.9,
      "humidity": 66,
      "wind": 6.3,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DNAI",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DNAI_03",
      "name": "Trạm Vườn Quốc gia Cát Tiên",
      "type": "Trạm nền rừng nhiệt đới",
      "address": "Huyện Tân Phú",
      "lat": 11.425,
      "lon": 107.415,
      "pm25": 16.2,
      "pm10": 24.3,
      "aqi": 29,
      "temp": 31.7,
      "humidity": 66,
      "wind": 6.1,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DNAI",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_TNINH": [
    {
      "id": "VN_TNINH_01",
      "name": "Trạm TP Tây Ninh - Trung tâm Đô thị",
      "type": "Đô thị",
      "address": "Đường 30/4, P. 3, TP. Tây Ninh",
      "lat": 11.312,
      "lon": 106.099,
      "pm25": 9.6,
      "pm10": 14.4,
      "aqi": 17,
      "temp": 32.4,
      "humidity": 57,
      "wind": 8.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TNINH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TNINH_02",
      "name": "Trạm Đỉnh Núi Bà Đen - Khí tượng Cao nguyên",
      "type": "Trạm nền khí hậu núi cao",
      "address": "Khu du lịch Quốc gia Núi Bà Đen",
      "lat": 11.385,
      "lon": 106.168,
      "pm25": 8.4,
      "pm10": 12.6,
      "aqi": 15,
      "temp": 32.0,
      "humidity": 61,
      "wind": 7.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TNINH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TNINH_03",
      "name": "Trạm KCN Trảng Bàng - Cửa khẩu Mộc Bài",
      "type": "Công nghiệp & Giao thông",
      "address": "KCN Trảng Bàng, TX. Trảng Bàng",
      "lat": 11.035,
      "lon": 106.355,
      "pm25": 9.6,
      "pm10": 14.4,
      "aqi": 17,
      "temp": 32.4,
      "humidity": 62,
      "wind": 8.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TNINH",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_TNINH_04",
      "name": "Trạm Tòa Thánh Tây Ninh - Tâm linh",
      "type": "Văn hóa du lịch",
      "address": "Phường Hiệp Ninh, TP. Tây Ninh",
      "lat": 11.305,
      "lon": 106.135,
      "pm25": 9.6,
      "pm10": 14.4,
      "aqi": 17,
      "temp": 32.4,
      "humidity": 62,
      "wind": 8.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_TNINH",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_CT": [
    {
      "id": "VN_CT_01",
      "name": "Trạm Bến Ninh Kiều - Trung tâm",
      "type": "Đô thị sông nước",
      "address": "Đường Hai Bà Trưng, P. Tân An, Q. Ninh Kiều",
      "lat": 10.035,
      "lon": 105.789,
      "pm25": 15.2,
      "pm10": 22.8,
      "aqi": 27,
      "temp": 30.8,
      "humidity": 65,
      "wind": 19.0,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_CT_02",
      "name": "Trạm KCN Trà Nóc & Cảng Cần Thơ",
      "type": "Công nghiệp cảng",
      "address": "KCN Trà Nóc 1, Q. Bình Thủy",
      "lat": 10.085,
      "lon": 105.725,
      "pm25": 17.6,
      "pm10": 26.4,
      "aqi": 32,
      "temp": 31.6,
      "humidity": 65,
      "wind": 19.8,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_CT_03",
      "name": "Trạm Chợ Nổi Cái Răng",
      "type": "Nông nghiệp du lịch sinh thái",
      "address": "Quận Cái Răng",
      "lat": 10.005,
      "lon": 105.745,
      "pm25": 16.4,
      "pm10": 24.6,
      "aqi": 30,
      "temp": 31.2,
      "humidity": 62,
      "wind": 19.4,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CT",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_DT": [
    {
      "id": "VN_DT_01",
      "name": "Trạm TP Cao Lãnh - Trung tâm",
      "type": "Đô thị",
      "address": "Đường Lý Thường Kiệt, P. 1",
      "lat": 10.459,
      "lon": 105.635,
      "pm25": 11.2,
      "pm10": 16.8,
      "aqi": 20,
      "temp": 31.7,
      "humidity": 57,
      "wind": 12.9,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DT_02",
      "name": "Trạm Làng Hoa Sa Đéc",
      "type": "Nông nghiệp hoa kiểng",
      "address": "Xã Tân Quy Đông, TP. Sa Đéc",
      "lat": 10.315,
      "lon": 105.755,
      "pm25": 11.8,
      "pm10": 17.7,
      "aqi": 21,
      "temp": 31.9,
      "humidity": 62,
      "wind": 13.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DT",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_DT_03",
      "name": "Trạm Vườn Quốc gia Tràm Chim",
      "type": "Trạm nền ngập nước",
      "address": "Thị trấn Tràm Chim, H. Tam Nông",
      "lat": 10.715,
      "lon": 105.515,
      "pm25": 13.6,
      "pm10": 20.4,
      "aqi": 24,
      "temp": 32.5,
      "humidity": 58,
      "wind": 13.7,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_DT",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_VL": [
    {
      "id": "VN_VL_01",
      "name": "Trạm Trung tâm TP Vĩnh Long",
      "type": "Đô thị",
      "address": "Đường Trưng Nữ Vương, P. 1",
      "lat": 10.255,
      "lon": 105.975,
      "pm25": 14.6,
      "pm10": 21.9,
      "aqi": 26,
      "temp": 31.2,
      "humidity": 62,
      "wind": 16.5,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_VL",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_VL_02",
      "name": "Trạm Cù lao An Bình - Miệt vườn",
      "type": "Sinh thái sông nước",
      "address": "Huyện Long Hồ",
      "lat": 10.285,
      "lon": 105.985,
      "pm25": 15.8,
      "pm10": 23.7,
      "aqi": 28,
      "temp": 31.6,
      "humidity": 65,
      "wind": 16.9,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_VL",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_VL_03",
      "name": "Trạm KCN Hòa Phú",
      "type": "Công nghiệp",
      "address": "Xã Hòa Phú, H. Long Hồ",
      "lat": 10.185,
      "lon": 105.955,
      "pm25": 15.2,
      "pm10": 22.8,
      "aqi": 27,
      "temp": 31.4,
      "humidity": 59,
      "wind": 16.7,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_VL",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_AG": [
    {
      "id": "VN_AG_01",
      "name": "Trạm TP Long Xuyên - Trung tâm",
      "type": "Đô thị",
      "address": "Đường Hà Hoàng Hổ, P. Mỹ Xuyên",
      "lat": 10.385,
      "lon": 105.42,
      "pm25": 11.2,
      "pm10": 16.8,
      "aqi": 20,
      "temp": 32.0,
      "humidity": 56,
      "wind": 14.6,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_AG",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_AG_02",
      "name": "Trạm TP Châu Đốc - Núi Sam",
      "type": "Du lịch tâm linh biên giới",
      "address": "Phường Núi Sam, TP. Châu Đốc",
      "lat": 10.685,
      "lon": 105.155,
      "pm25": 13.0,
      "pm10": 19.5,
      "aqi": 23,
      "temp": 32.6,
      "humidity": 56,
      "wind": 15.2,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_AG",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_AG_03",
      "name": "Trạm Rừng Tràm Trà Sư",
      "type": "Trạm nền sinh thái rừng ngập phèn",
      "address": "Xã Văn Giáo, TX. Tịnh Biên",
      "lat": 10.512,
      "lon": 105.052,
      "pm25": 12.4,
      "pm10": 18.6,
      "aqi": 22,
      "temp": 32.4,
      "humidity": 53,
      "wind": 15.0,
      "aqi_level": "Trung bình",
      "color": "#f59e0b",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_AG",
      "timestamp": "2026-11-08 12:45:43"
    }
  ],
  "VN_CM": [
    {
      "id": "VN_CM_01",
      "name": "Trạm Trung tâm TP Cà Mau",
      "type": "Đô thị",
      "address": "Đường Hùng Vương, P. 5",
      "lat": 9.18,
      "lon": 105.155,
      "pm25": 10.8,
      "pm10": 16.2,
      "aqi": 19,
      "temp": 31.8,
      "humidity": 68,
      "wind": 19.1,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CM",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_CM_02",
      "name": "Trạm Cột Mốc Tọa Độ Đất Mũi",
      "type": "Trạm nền sinh thái cực Nam",
      "address": "Xã Đất Mũi, H. Ngọc Hiển",
      "lat": 8.615,
      "lon": 104.725,
      "pm25": 9.6,
      "pm10": 14.4,
      "aqi": 17,
      "temp": 31.4,
      "humidity": 70,
      "wind": 18.7,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CM",
      "timestamp": "2026-11-08 12:45:43"
    },
    {
      "id": "VN_CM_03",
      "name": "Trạm KCN Khí - Điện - Đạm Cà Mau",
      "type": "Công nghiệp năng lượng",
      "address": "Xã Khánh An, H. U Minh",
      "lat": 9.285,
      "lon": 105.015,
      "pm25": 9.0,
      "pm10": 13.5,
      "aqi": 16,
      "temp": 31.2,
      "humidity": 71,
      "wind": 18.5,
      "aqi_level": "Tốt",
      "color": "#10b981",
      "status": "Đang hoạt động 24/7 (Realtime Live)",
      "province_id": "VN_CM",
      "timestamp": "2026-11-08 12:45:43"
    }
  ]
}
